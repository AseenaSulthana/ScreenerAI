# Deccan AI Experts - User Guide

## Quick Start

### Accessing the Platform
1. Open http://localhost:3000 in your browser
2. You'll land on the **Dashboard** - the recruitment overview page

## Main Features

### 🏠 Dashboard (`/`)
**Your recruitment hub with real-time metrics**

What you see:
- **5 KPI Cards** at the top showing:
  - Active Jobs: 12 (↑ 20% from last week)
  - Candidates Discovered: 1,243 (↑ 15%)
  - Conversations: 576 (↑ 10%)
  - Response Rate: 42% (↑ 12%)
  - Shortlists Ready: 48 (↑ 23%)

- **Pipeline Overview**: Visual funnel showing candidate progression
  - JD Parsing: 12 completed
  - Candidate Discovery: 8 in progress
  - Engagement: 6 in progress
  - Shortlist Ready: 18 completed

- **Top Performing Job**: Senior Machine Learning Engineer
  - 320 candidates discovered
  - 48% response rate
  - 12 candidates shortlisted

- **Recent Jobs Table**: List of recent job postings with metrics
- **AI Insights**: Machine learning-generated recruitment insights

### 🔍 JD Parser (`/jd-parser`) ⭐ STAR FEATURE
**Upload resumes and find matching candidates automatically**

#### Step 1: Upload Resumes
```
Click "Upload Resumes" or drag & drop files
Supported formats: PDF, DOC, DOCX
Can upload multiple files at once
Max 10MB per file
```

#### Step 2: Enter Job Description
```
Paste the complete job description
Or upload a JD file
The system reads and analyzes the requirements
```

#### Step 3: Add Requirements
Fill in the right-side panel:

**Job Information**
- Job Title (e.g., "Senior ML Engineer")
- Department (e.g., "Engineering")
- Years of Experience (e.g., "4+ years")
- Education (e.g., "Bachelor's / Master's in CS")

**Required Skills**
- Click "+ Add Skill"
- Type skill and hit Enter
- Skill appears in blue box
- Click X to remove

**Key Responsibilities**
- Click "+ Add Responsibility"
- Type responsibility and hit Enter
- Responsibility appears in teal box
- Click X to remove

#### Step 4: Parse & Find Matches
- Click the big button "Parse JD & Find Matches"
- System analyzes resumes against requirements
- AI extracts key skills and experience from JD
- Matches candidates with scores

#### Step 5: Review Results
See matched candidates with:
- **Match Score**: 0-100% (skills alignment)
- **Interest Score**: 0-100% (engagement level)
- **Relevant Skills**: Highlighted matches
- **Location & Experience**: Candidate details
- **Actions**: 
  - Click "Engage" to start conversation
  - Click "Resume" to download file

#### Step 6: Export & Sync
- **Modify JD**: Go back to editor
- **Sync to ATS**: Send to Workday/Greenhouse/LinkedIn
- **Export Results**: Download CSV/PDF with results

### 📋 Jobs (`/jobs`)
**Manage your job postings**

Features:
- View all active job listings
- See candidate count per position
- Check performance metrics
- Quick actions for each job
- Create new job postings

### 👥 Candidates (`/candidates`)
**Browse candidate profiles**

What you can do:
- Search candidates by name
- Filter by skills, experience, location
- View engagement history
- See match scores
- Add notes to profiles
- Track candidate status

### 💬 Engagements (`/engagements`)
**AI-powered candidate conversations**

Track:
- Ongoing conversations with candidates
- Last message and timestamps
- Response rates
- Engagement status:
  - 🔵 In Progress (active conversation)
  - ⏳ Waiting (awaiting candidate reply)
  - ✅ Completed (conversation done)
- Continue chat directly from this page

### ⭐ Shortlists (`/shortlists`)
**Manage candidate shortlists**

For each shortlist, see:
- List name (e.g., "Senior ML Engineer - Round 1")
- Job ID reference
- Total candidates
- Top candidate and score
- Creation date
- Quick actions:
  - 👁️ View - See full shortlist
  - 📤 Share - Send to hiring manager
  - 📥 Export - Download results
  - 🗑️ Delete - Remove shortlist

### 📊 Analytics (`/analytics`)
**Recruitment metrics and insights**

Key metrics displayed:
- **Total Candidates Sourced**: 1,242 (+12%)
- **Avg Response Time**: 2.4 hours (-8%)
- **Conversion Rate**: 34% (+5%)
- **Engagement Score**: 8.2/10 (+2.1%)

Advanced charts coming soon:
- Recruitment funnel
- Source analysis
- Time-to-hire metrics
- Channel performance

### 🔗 ATS Integrations (`/integrations`)
**Connect your recruitment tools**

Available integrations:
- ✅ Workday (Connected)
- ✅ LinkedIn Recruiter (Connected)
- ✅ Gmail (Connected)
- ⚪ Slack (Available)
- ⚪ Microsoft Teams (Available)
- ⚪ Greenhouse (Available)

To connect:
1. Click on integration
2. Authenticate with your credentials
3. Grant permissions
4. Status changes to "Connected"

### ⚙️ Settings (`/settings`)
**Manage your account**

Sections:
1. **Profile**
   - Full name
   - Email address
   - Company
   - Save changes

2. **Notifications**
   - Email notifications
   - Slack notifications
   - New candidate alerts
   - Engagement updates

3. **Security**
   - Change password
   - Enable 2FA
   - View active sessions

4. **Appearance**
   - Dark mode (default)
   - Light mode
   - Theme preferences

### 🔄 Workflow (`/workflow`)
**5-step interactive recruitment process**

Steps:
1. **JD Input** - Upload or paste job description
2. **JD Parsing** - AI extracts requirements with confidence
3. **Candidate Discovery** - Browse and filter candidates
4. **Engagement** - Chat with candidates, track interest
5. **Shortlist** - View scatter plot and ranked candidates

Navigate steps:
- Click step numbers to jump
- Or click "Next" to progress
- Progress bar shows completion percentage

## Navigation Guide

### Using the Sidebar
Left sidebar always shows:
1. **Deccan Experts** Logo at top
2. **Navigation items** (10 total):
   - 🏠 Dashboard
   - 🔍 JD Parser
   - 📋 Job Descriptions
   - 👥 Candidates
   - 💬 Engagements
   - ⭐ Shortlists
   - 📊 Analytics
   - 🔗 ATS Integrations
   - ⚙️ Settings

3. **User Info** at bottom (Rohit Sharma, Recruiter)

Active page is highlighted in cyan.

### Using the Top Navbar
Right-side buttons:
- 🔍 Search bar (find candidates, jobs)
- 🔔 Notifications bell
- ⚙️ Settings gear icon
- 👤 User profile menu

## Common Tasks

### Task 1: Find Candidates for a Job

1. Go to **JD Parser**
2. Upload candidate resumes
3. Paste job description
4. Fill in requirements:
   - Job title
   - Experience needed
   - Skills required
   - Responsibilities
5. Click "Parse & Find Matches"
6. Review matched candidates
7. Click "Engage" to start conversation

**Time**: 5-10 minutes

### Task 2: Manage a Shortlist

1. Go to **Shortlists**
2. Click on a shortlist to view
3. See candidates ranked by match score
4. Click actions:
   - 👁️ View candidate profile
   - 📤 Share shortlist with team
   - 📥 Export to Excel/PDF
5. Or sync to ATS with one click

**Time**: 2-5 minutes

### Task 3: Track Engagement

1. Go to **Engagements**
2. See all active conversations
3. Click "Continue Chat" on any candidate
4. View:
   - Response rate %
   - Engagement depth %
   - Sentiment analysis
5. Send next message

**Time**: 3-7 minutes

### Task 4: View Analytics

1. Go to **Analytics**
2. See key metrics at top:
   - Candidates sourced
   - Response time
   - Conversion rate
   - Engagement score
3. View trends (up/down %)
4. Charts show detailed analysis

**Time**: 1-2 minutes

## Best Practices

### When Using JD Parser
✅ **DO:**
- Upload 10-50 resumes at a time
- Provide complete, detailed job descriptions
- List all must-have skills
- Include key responsibilities
- Use consistent experience format ("4+ years")

❌ **DON'T:**
- Upload 100+ resumes at once (use batches)
- Leave job description blank
- Use vague skill requirements
- Upload files larger than 10MB
- Use handwritten resume PDFs (won't parse)

### For Best Match Results
1. **Complete all fields** in the form
2. **Add 5-10 required skills** for better matching
3. **Include responsibilities** to understand role
4. **Specify education requirements** clearly
5. **Set experience level** accurately

### Managing Candidates
1. **Regular engagement** increases response rate
2. **Tag candidates** in notes for easy filtering
3. **Export shortlists** regularly for stakeholders
4. **Track response time** to optimize process
5. **Use ATS sync** to keep systems updated

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Cmd/Ctrl + K` | Open search |
| `Escape` | Close modals |
| `Enter` | Add item (skills, responsibilities) |
| `Click X` | Remove item |
| `Tab` | Navigate form fields |

## FAQ

### Q: Can I upload resumes without a job description?
**A:** The JD Parser works best with both. System can still analyze skills but won't match against role requirements.

### Q: What file formats are supported?
**A:** PDF, DOC, and DOCX files up to 10MB each.

### Q: How long does parsing take?
**A:** Usually 2-5 seconds depending on file size and quantity.

### Q: Can I edit requirements after parsing?
**A:** Yes! Click "Modify JD" to go back and adjust requirements.

### Q: How are match scores calculated?
**A:** Algorithm weighs skill overlap, experience level, education match, and responsibility fit.

### Q: Can I export results?
**A:** Yes! Export as CSV, PDF, or sync directly to your ATS.

## Troubleshooting

### Files won't upload
- Check file size (max 10MB)
- Ensure format is PDF/DOC/DOCX
- Try different file
- Refresh page and retry

### Match scores seem low
- Resumes may not have all required skills listed
- Job description too specialized
- Candidates from different background
- Add more context in JD

### Candidates not matching
- Upload more resumes
- Reduce required skills count
- Check skill spelling consistency
- Make requirements less strict

### Export not working
- Check browser permissions
- Disable popup blocker
- Try different export format
- Try different browser

## Support
For issues or questions, contact support@deccanexperts.com
