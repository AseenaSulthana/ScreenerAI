export const dashboardStats = {
  activeJobs: { value: 12, change: 20, unit: 'from last week' },
  candidatesDiscovered: { value: 1243, change: 12, unit: 'from last week' },
  conversations: { value: 876, change: 8, unit: 'from last week' },
  avgResponseRate: { value: 42, change: 12, unit: 'from last week' },
  shortlistsReady: { value: 24, change: 25, unit: 'from last week' },
}

export const pipelineStages = [
  { name: 'JD Parsing', count: 12, status: 'completed' },
  { name: 'Candidate Discovery', count: 8, status: 'inProgress' },
  { name: 'Engagement', count: 6, status: 'inProgress' },
  { name: 'Shortlist Ready', count: 18, status: 'completed' },
]

export const topPerformingJob = {
  title: 'Senior Machine Learning Engineer',
  status: 'Shortlist Ready',
  candidatesDiscovered: 320,
  responseRate: 48,
  shortlist: 12,
}

export const recentJobs = [
  {
    id: 1,
    title: 'Senior Machine Learning Engineer',
    status: 'Shortlist Ready',
    candidatesDiscovered: 320,
    responseRate: 48,
    updatedAt: '2h ago',
    shortlist: 12,
  },
  {
    id: 2,
    title: 'AI Research Scientist',
    status: 'Engagement',
    candidatesDiscovered: 210,
    responseRate: 41,
    updatedAt: '5h ago',
    shortlist: 8,
  },
  {
    id: 3,
    title: 'Data Engineer',
    status: 'Discovery',
    candidatesDiscovered: 156,
    responseRate: 35,
    updatedAt: '1d ago',
    shortlist: 6,
  },
  {
    id: 4,
    title: 'ML Engineer',
    status: 'JD Parsing',
    candidatesDiscovered: 150,
    responseRate: 0,
    updatedAt: '1d ago',
    shortlist: 4,
  },
  {
    id: 5,
    title: 'Computer Vision Engineer',
    status: 'Discovery',
    candidatesDiscovered: 120,
    responseRate: 36,
    updatedAt: '2d ago',
    shortlist: 0,
  },
]

export const aiInsights = [
  {
    icon: '📈',
    text: 'High match candidates are responding better between 10 AM - 2 PM',
  },
  {
    icon: '🎯',
    text: 'Roles with NLP skills have 27% higher engagement',
  },
  {
    icon: '⚡',
    text: 'Your response rate is 12% higher than last week',
  },
]

export const candidates = [
  {
    id: 1,
    name: 'Arjun Mehta',
    role: 'Senior ML Engineer @ Google',
    experience: '5 Yrs',
    location: 'Bangalore, India',
    skills: ['Python', 'NLP', 'LLMs', 'AWS'],
    matchScore: 92,
    interestScore: 90,
    image: '👨‍💼',
  },
  {
    id: 2,
    name: 'Neha Iyer',
    role: 'ML Engineer @ Microsoft',
    experience: '4 Yrs',
    location: 'Hyderabad, India',
    skills: ['Python', 'NLP', 'Deep Learning', 'GCP'],
    matchScore: 88,
    interestScore: 85,
    image: '👩‍💼',
  },
  {
    id: 3,
    name: 'Rohan Deshpande',
    role: 'NLP Engineer @ IBM',
    experience: '4.5 Yrs',
    location: 'Pune, India',
    skills: ['Python', 'NLP', 'Transformers', 'AWS'],
    matchScore: 85,
    interestScore: 78,
    image: '👨‍💼',
  },
  {
    id: 4,
    name: 'Sneha Kapoor',
    role: 'ML Engineer @ Amazon',
    experience: '5 Yrs',
    location: 'Gurgaon, India',
    skills: ['Python', 'Deep Learning', 'LLMs', 'AWS'],
    matchScore: 82,
    interestScore: 75,
    image: '👩‍💼',
  },
  {
    id: 5,
    name: 'Vikram Singh',
    role: 'Data Scientist @ LinkedIn',
    experience: '6 Yrs',
    location: 'Mumbai, India',
    skills: ['Python', 'ML', 'Data Science', 'AWS'],
    matchScore: 78,
    interestScore: 70,
    image: '👨‍💼',
  },
  {
    id: 6,
    name: 'Priya Sharma',
    role: 'ML Engineer @ Google',
    experience: '3.5 Yrs',
    location: 'Bangalore, India',
    skills: ['Python', 'LLMs', 'NLP', 'GCP'],
    matchScore: 88,
    interestScore: 82,
    image: '👩‍💼',
  },
]

export const jobDescription = `We are looking for a Senior Machine Learning Engineer with strong experience in Python, NLP, LLMs, and cloud platforms.

Requirements:
- 4+ years of experience in ML
- Strong Python skills
- Experience with NLP and Large Language Models
- AWS or GCP experience
- Experience with ML systems and deployment

Responsibilities:
- Work with cross-functional teams
- Develop and deploy ML models
- Optimize production systems
- Mentor junior engineers`

export const parsedInsights = [
  { label: 'Role', value: 'Senior Machine Learning Engineer', confidence: 98 },
  { label: 'Experience', value: '4+ Years', confidence: 96 },
  { label: 'Top Skills', value: 'Python, NLP, LLMs, AWS', confidence: 95 },
  { label: 'Key Responsibilities', value: 'Model Development, Deployment, Optimization', confidence: 93 },
  { label: 'Education', value: 'CS/Related field (implied)', confidence: 88 },
]

export const engagementConversation = [
  {
    role: 'ai',
    message:
      'Hi Arjun! We have an exciting opportunity for a Senior ML Engineer role at Deccan. Your profile matches perfectly with our requirements.',
  },
  {
    role: 'candidate',
    message: 'Thank you! I am actively looking for new opportunities. Can you tell me more about the role?',
  },
  {
    role: 'ai',
    message:
      'Absolutely! The role involves working with cutting-edge LLMs and building scalable ML systems. The team is based in Bangalore with flexible WFH options.',
  },
  {
    role: 'candidate',
    message: "That sounds great! What's the compensation range and when are you looking to hire?",
  },
  {
    role: 'ai',
    message:
      'We are looking for immediate start or 30-day notice. Compensation is competitive (25-35 LPA). Would you be interested in learning more?',
  },
]

export const interestBreakdown = [
  { label: 'Role Match', value: 92, color: '#00FFC6' },
  { label: 'Company Culture', value: 88, color: '#00C2A8' },
  { label: 'Compensation', value: 85, color: '#0099CC' },
  { label: 'Growth Opportunity', value: 90, color: '#00E6D9' },
]

export const shortlistCandidates = [
  {
    rank: 1,
    name: 'Arjun Mehta',
    matchScore: 92,
    interestScore: 90,
    summary: 'Strong match in skills and experience. Highly interested in the role.',
  },
  {
    rank: 2,
    name: 'Neha Iyer',
    matchScore: 88,
    interestScore: 85,
    summary: 'Good match with relevant experience. Actively exploring opportunities.',
  },
  {
    rank: 3,
    name: 'Rohan Deshpande',
    matchScore: 85,
    interestScore: 78,
    summary: 'Good technical fit. Interested but evaluating multiple offers.',
  },
  {
    rank: 4,
    name: 'Sneha Kapoor',
    matchScore: 82,
    interestScore: 75,
    summary: 'Skill match good. Moderate interest in the role.',
  },
]
