export interface Candidate {
  id: number
  name: string
  role: string
  experience: string
  location: string
  skills: string[]
  matchScore: number
  interestScore: number
  image: string
  company?: string
}

export interface Job {
  id: number
  title: string
  status: string
  candidatesCount: number
  responseRate: number
  updated: string
  shortlistCount: number
}

export interface ParsedInsight {
  label: string
  value: string
  confidence: number
}

export interface Conversation {
  role: 'ai' | 'candidate'
  message: string
  timestamp?: string
}
