'use client'

import { Sidebar } from '@/components/layout/Sidebar'
import { Navbar } from '@/components/layout/Navbar'
import { Download, Share2, Trash2, Eye } from 'lucide-react'

export default function ShortlistsPage() {
  const shortlists = [
    {
      id: 1,
      title: 'Senior ML Engineer - Round 1',
      jobId: 'JOB-001',
      totalCandidates: 4,
      topCandidate: 'Arjun Mehta',
      topScore: 92,
      createdDate: '2 days ago',
      status: 'active',
    },
    {
      id: 2,
      title: 'Data Scientist - Final Round',
      jobId: 'JOB-002',
      totalCandidates: 3,
      topCandidate: 'Priya Sharma',
      topScore: 88,
      createdDate: '1 week ago',
      status: 'completed',
    },
    {
      id: 3,
      title: 'Frontend Engineer - Round 2',
      jobId: 'JOB-003',
      totalCandidates: 6,
      topCandidate: 'Rahul Kumar',
      topScore: 85,
      createdDate: '3 days ago',
      status: 'active',
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <Navbar />

      <main className="ml-56 mt-16 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">Shortlists</h1>
            <p className="text-gray-400">Manage and export candidate shortlists</p>
          </div>

          <div className="grid gap-4">
            {shortlists.map((list) => (
              <div key={list.id} className="glass-card-hover p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-white">{list.title}</h3>
                      <span className={`status-badge ${list.status === 'active' ? 'status-shortlist' : 'bg-gray-400/20 text-gray-300 border-gray-400/30'}`}>
                        {list.status === 'active' ? 'Active' : 'Completed'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-400 mb-3">Job ID: {list.jobId}</p>
                    <div className="flex items-center gap-6 text-sm text-gray-300">
                      <div>
                        <p className="text-gray-500 text-xs mb-1">Total Candidates</p>
                        <p className="font-semibold text-white">{list.totalCandidates}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 text-xs mb-1">Top Candidate</p>
                        <p className="font-semibold text-cyan-300">{list.topCandidate}</p>
                      </div>
                      <div>
                        <p className="text-gray-500 text-xs mb-1">Top Score</p>
                        <div className="flex items-center gap-2">
                          <div className="w-16 h-2 bg-white/10 rounded-full overflow-hidden">
                            <div className="h-full bg-cyan-400" style={{ width: `${list.topScore}%` }} />
                          </div>
                          <span className="font-semibold text-cyan-400">{list.topScore}%</span>
                        </div>
                      </div>
                      <div>
                        <p className="text-gray-500 text-xs mb-1">Created</p>
                        <p className="font-semibold text-white">{list.createdDate}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2 ml-6">
                    <button className="p-2 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-cyan-400 border border-white/10 rounded-lg transition-colors" title="View">
                      <Eye className="w-4 h-4" />
                    </button>
                    <button className="p-2 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-cyan-400 border border-white/10 rounded-lg transition-colors" title="Share">
                      <Share2 className="w-4 h-4" />
                    </button>
                    <button className="p-2 bg-white/5 hover:bg-white/10 text-gray-400 hover:text-cyan-400 border border-white/10 rounded-lg transition-colors" title="Export">
                      <Download className="w-4 h-4" />
                    </button>
                    <button className="p-2 bg-white/5 hover:bg-red-500/20 text-gray-400 hover:text-red-400 border border-white/10 rounded-lg transition-colors" title="Delete">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
