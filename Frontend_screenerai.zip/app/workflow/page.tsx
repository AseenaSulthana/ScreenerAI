'use client'

import { Sidebar } from '@/components/layout/Sidebar'
import { Navbar } from '@/components/layout/Navbar'
import { JDInput } from '@/components/workflow/JDInput'
import { ParsedInsights } from '@/components/workflow/ParsedInsights'
import { CandidateDiscovery } from '@/components/workflow/CandidateDiscovery'
import { ChatbotPanel } from '@/components/workflow/ChatbotPanel'
import { InterestScore } from '@/components/workflow/InterestScore'
import { ScatterPlot } from '@/components/workflow/ScatterPlot'
import { ShortlistTable } from '@/components/workflow/ShortlistTable'
import { useState } from 'react'

const steps = [
  { id: 1, name: 'JD Input', icon: '📄' },
  { id: 2, name: 'JD Parsing', icon: '⚙️' },
  { id: 3, name: 'Candidate Discovery', icon: '🔍' },
  { id: 4, name: 'Engagement', icon: '💬' },
  { id: 5, name: 'Shortlist', icon: '✅' },
]

export default function WorkflowPage() {
  const [currentStep, setCurrentStep] = useState(1)

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleStepClick = (stepId: number) => {
    setCurrentStep(stepId)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Layout */}
      <Sidebar />
      <Navbar />

      {/* Main content */}
      <main className="ml-56 mt-16 p-6">
        {/* Step Indicator */}
        <div className="mb-8">
          <div className="relative flex items-center justify-between mb-6 px-4">
            {steps.map((step, index) => (
              <div key={step.id} className="flex flex-col items-center flex-1 relative">
                {/* Step Circle */}
                <button
                  onClick={() => handleStepClick(step.id)}
                  className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg mb-3 transition-all cursor-pointer relative z-10 ${
                    currentStep === step.id
                      ? 'bg-cyan-400/30 text-cyan-300 border-2 border-cyan-400 animate-pulse-glow'
                      : currentStep > step.id
                        ? 'bg-green-400/30 text-green-300 border-2 border-green-400'
                        : 'bg-white/10 text-gray-400 border-2 border-white/10'
                  }`}
                >
                  {currentStep > step.id ? '✓' : step.icon}
                </button>

                {/* Connecting Line */}
                {index < steps.length - 1 && (
                  <div
                    className={`absolute top-6 left-1/2 w-full h-1 transition-all duration-300 ${
                      currentStep > step.id ? 'bg-gradient-to-r from-green-400 to-green-400/50' : 'bg-white/10'
                    }`}
                    style={{
                      marginLeft: `calc(24px)`,
                    }}
                  />
                )}

                {/* Step Name */}
                <p className={`text-xs font-medium text-center transition-colors max-w-16 ${
                  currentStep === step.id ? 'text-cyan-400' : 'text-gray-500'
                }`}>
                  {step.name}
                </p>
              </div>
            ))}
          </div>

          {/* Progress Bar */}
          <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 to-teal-400 rounded-full transition-all duration-500"
              style={{ width: `${(currentStep / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Content - Full width panel */}
        <div className="glass-card-hover p-8 mb-8 min-h-[500px] animate-slide-up">
          {currentStep === 1 && <JDInput onNext={handleNext} />}
          {currentStep === 2 && <ParsedInsights onNext={handleNext} />}
          {currentStep === 3 && <CandidateDiscovery onNext={handleNext} />}
          {currentStep === 4 && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ChatbotPanel onNext={handleNext} />
              </div>
              <div className="lg:col-span-1">
                <InterestScore score={88} />
              </div>
            </div>
          )}
          {currentStep === 5 && (
            <div className="space-y-6">
              <ShortlistTable onComplete={handleNext} />
              <ScatterPlot />
            </div>
          )}
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between items-center">
          <button
            onClick={handlePrevious}
            disabled={currentStep === 1}
            className={`px-6 py-3 rounded-lg font-semibold transition-all ${
              currentStep === 1
                ? 'bg-white/5 text-gray-500 cursor-not-allowed border border-white/10'
                : 'bg-white/10 text-gray-300 hover:bg-white/20 border border-white/20'
            }`}
          >
            Previous
          </button>

          <div className="text-center">
            <p className="text-gray-400 text-sm">
              Step <span className="text-cyan-400 font-bold">{currentStep}</span> of{' '}
              <span className="text-cyan-400 font-bold">{steps.length}</span>
            </p>
          </div>

          <button
            onClick={handleNext}
            disabled={currentStep === steps.length}
            className={`px-6 py-3 rounded-lg font-semibold transition-all ${
              currentStep === steps.length
                ? 'bg-green-400/20 text-green-400 border border-green-400/30 cursor-default'
                : 'bg-gradient-to-r from-cyan-400 to-teal-400 text-black hover:shadow-lg hover:shadow-cyan-500/30'
            }`}
          >
            {currentStep === steps.length ? '✓ Complete' : 'Next'}
          </button>
        </div>
      </main>
    </div>
  )
}
