'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Eye, EyeOff } from 'lucide-react'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    // Simulate login
    setTimeout(() => {
      if (email && password) {
        // In production, make API call here
        console.log('Login attempt:', { email, password })
        // Redirect to dashboard
        window.location.href = '/'
      } else {
        setError('Please enter both email and password')
      }
      setIsLoading(false)
    }, 1000)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#061A1A] via-[#0B2F2F] to-[#061A1A] flex items-center justify-center p-4">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-cyan-400/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-teal-400/5 rounded-full blur-3xl animate-pulse" />
      </div>

      {/* Login Container */}
      <div className="relative z-10 w-full max-w-md">
        <div className="glass-card p-8 space-y-8">
          {/* Header with Chatbot */}
          <div className="flex flex-col items-center space-y-4">
            <img
              src="/chatbot.png"
              alt="Deccan AI Experts Chatbot"
              className="w-32 h-32 drop-shadow-2xl animate-slide-up"
            />
            <div className="text-center">
              <h1 className="text-3xl font-bold text-white mb-2">
                <span className="text-cyan-400">Deccan</span> AI Experts
              </h1>
              <p className="text-gray-400 text-sm">AI-Powered Recruitment Platform</p>
            </div>
          </div>

          {/* Chat Bubble from Chatbot */}
          <div className="relative">
            <div className="glass-card-hover p-4 rounded-2xl">
              <p className="text-gray-300 text-center text-sm flex items-center gap-2">
                <span className="text-cyan-400">👋</span>
                Welcome! Let&apos;s find great talent together
              </p>
            </div>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="bg-red-500/20 border border-red-400/30 text-red-300 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            {/* Email Input */}
            <div className="space-y-2">
              <label htmlFor="email" className="text-sm font-medium text-gray-300">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400/50 focus:ring-1 focus:ring-cyan-400/20 transition-all duration-200"
              />
            </div>

            {/* Password Input */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label htmlFor="password" className="text-sm font-medium text-gray-300">
                  Password
                </label>
                <Link
                  href="/forgot-password"
                  className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
                >
                  Forgot?
                </Link>
              </div>
              <div className="relative">
                <input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cyan-400/50 focus:ring-1 focus:ring-cyan-400/20 transition-all duration-200"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-cyan-400 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            {/* Login Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-6 px-4 py-3 bg-gradient-to-r from-cyan-400 to-teal-400 text-slate-900 font-semibold rounded-lg hover:from-cyan-300 hover:to-teal-300 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-900/20 border-t-slate-900 rounded-full animate-spin" />
                  Signing in...
                </>
              ) : (
                'Sign In'
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-white/10" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-gradient-to-br from-[#061A1A] via-[#0B2F2F] to-[#061A1A] text-gray-400">
                Demo Account
              </span>
            </div>
          </div>

          {/* Demo Credentials */}
          <div className="bg-blue-500/10 border border-blue-400/20 rounded-lg p-4 space-y-2 text-sm">
            <p className="text-blue-300 font-medium">Try with demo credentials:</p>
            <p className="text-gray-400">
              <span className="text-gray-300">Email:</span> demo@deccan.ai
            </p>
            <p className="text-gray-400">
              <span className="text-gray-300">Password:</span> demo123
            </p>
          </div>

          {/* Footer Links */}
          <div className="text-center text-sm text-gray-400 space-y-2">
            <p>
              Don&apos;t have an account?{' '}
              <Link href="/signup" className="text-cyan-400 hover:text-cyan-300 font-medium transition-colors">
                Sign up
              </Link>
            </p>
            <p className="text-xs">
              By signing in, you agree to our{' '}
              <Link href="/terms" className="text-cyan-400 hover:text-cyan-300 transition-colors">
                Terms of Service
              </Link>
            </p>
          </div>
        </div>

        {/* Bottom Branding */}
        <div className="mt-8 text-center text-xs text-gray-500">
          <p>Deccan AI Experts © 2024</p>
        </div>
      </div>
    </div>
  )
}
