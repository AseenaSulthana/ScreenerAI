'use client'

import { Sidebar } from '@/components/layout/Sidebar'
import { Navbar } from '@/components/layout/Navbar'
import { User, Bell, Lock, Palette } from 'lucide-react'

export default function SettingsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <Navbar />

      <main className="ml-56 mt-16 p-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">Settings</h1>
            <p className="text-gray-400">Manage your account and preferences</p>
          </div>

          <div className="space-y-6">
            {/* Profile Settings */}
            <div className="glass-card-hover p-6">
              <div className="flex items-center gap-3 mb-4">
                <User className="w-5 h-5 text-cyan-400" />
                <h2 className="text-xl font-semibold text-white">Profile</h2>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Full Name</label>
                  <input
                    type="text"
                    defaultValue="Rohit Sharma"
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white focus:border-cyan-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Email</label>
                  <input
                    type="email"
                    defaultValue="rohit@deccanexperts.com"
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white focus:border-cyan-400 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Company</label>
                  <input
                    type="text"
                    defaultValue="Deccan AI Experts"
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white focus:border-cyan-400 focus:outline-none"
                  />
                </div>
                <button className="bg-gradient-to-r from-cyan-400 to-teal-400 hover:from-cyan-500 hover:to-teal-500 text-black px-6 py-2 rounded-lg font-medium transition-all">
                  Save Changes
                </button>
              </div>
            </div>

            {/* Notification Settings */}
            <div className="glass-card-hover p-6">
              <div className="flex items-center gap-3 mb-4">
                <Bell className="w-5 h-5 text-cyan-400" />
                <h2 className="text-xl font-semibold text-white">Notifications</h2>
              </div>
              <div className="space-y-3">
                {['Email notifications', 'Slack notifications', 'New candidate matches', 'Engagement updates'].map((item) => (
                  <label key={item} className="flex items-center gap-3 cursor-pointer">
                    <input type="checkbox" defaultChecked className="w-4 h-4" />
                    <span className="text-gray-300">{item}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Security Settings */}
            <div className="glass-card-hover p-6">
              <div className="flex items-center gap-3 mb-4">
                <Lock className="w-5 h-5 text-cyan-400" />
                <h2 className="text-xl font-semibold text-white">Security</h2>
              </div>
              <div className="space-y-4">
                <button className="bg-white/5 hover:bg-white/10 text-white border border-white/10 px-6 py-2 rounded-lg font-medium transition-colors">
                  Change Password
                </button>
                <button className="bg-white/5 hover:bg-white/10 text-white border border-white/10 px-6 py-2 rounded-lg font-medium transition-colors">
                  Enable Two-Factor Authentication
                </button>
              </div>
            </div>

            {/* Theme Settings */}
            <div className="glass-card-hover p-6">
              <div className="flex items-center gap-3 mb-4">
                <Palette className="w-5 h-5 text-cyan-400" />
                <h2 className="text-xl font-semibold text-white">Appearance</h2>
              </div>
              <div className="space-y-3">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="radio" name="theme" defaultChecked className="w-4 h-4" />
                  <span className="text-gray-300">Dark Mode (Default)</span>
                </label>
                <label className="flex items-center gap-3 cursor-pointer">
                  <input type="radio" name="theme" className="w-4 h-4" />
                  <span className="text-gray-300">Light Mode</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
