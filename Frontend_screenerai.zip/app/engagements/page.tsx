'use client'

import { Sidebar } from '@/components/layout/Sidebar'
import { Navbar } from '@/components/layout/Navbar'
import { MessageCircle, Clock, CheckCircle, AlertCircle } from 'lucide-react'

export default function EngagementsPage() {
  const engagements = [
    {
      id: 1,
      candidate: 'Arjun Mehta',
      role: 'Senior Machine Learning Engineer',
      status: 'in-progress',
      lastMessage: 'Yes, I&apos;m interested in the role!',
      messageTime: '2 hours ago',
      responseRate: 92,
    },
    {
      id: 2,
      candidate: 'Neha Iyer',
      role: 'Senior Machine Learning Engineer',
      status: 'in-progress',
      lastMessage: 'Can you share more about the team?',
      messageTime: '4 hours ago',
      responseRate: 88,
    },
    {
      id: 3,
      candidate: 'Rohan Deshpande',
      role: 'Senior Machine Learning Engineer',
      status: 'completed',
      lastMessage: 'Thank you for the opportunity!',
      messageTime: '1 day ago',
      responseRate: 85,
    },
    {
      id: 4,
      candidate: 'Sneha Kapoor',
      role: 'Senior Machine Learning Engineer',
      status: 'waiting',
      lastMessage: 'Waiting for candidate response...',
      messageTime: '3 days ago',
      responseRate: 0,
    },
  ]

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'in-progress':
        return 'bg-blue-400/20 text-blue-300 border-blue-400/30'
      case 'completed':
        return 'bg-green-400/20 text-green-300 border-green-400/30'
      case 'waiting':
        return 'bg-yellow-400/20 text-yellow-300 border-yellow-400/30'
      default:
        return 'bg-gray-400/20 text-gray-300 border-gray-400/30'
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <Navbar />

      <main className="ml-56 mt-16 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">Engagements</h1>
            <p className="text-gray-400">AI-powered candidate conversations and engagement tracking</p>
          </div>

          <div className="space-y-4">
            {engagements.map((eng) => (
              <div key={eng.id} className="glass-card-hover p-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <MessageCircle className="w-5 h-5 text-cyan-400" />
                      <h3 className="text-lg font-semibold text-white">{eng.candidate}</h3>
                      <span className={`status-badge ${getStatusColor(eng.status)}`}>
                        {eng.status === 'in-progress' && 'In Progress'}
                        {eng.status === 'completed' && 'Completed'}
                        {eng.status === 'waiting' && 'Waiting'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-400 mb-3">{eng.role}</p>
                    <p className="text-gray-300 mb-2">{eng.lastMessage}</p>
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {eng.messageTime}
                      </span>
                      {eng.responseRate > 0 && (
                        <span className="flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" />
                          {eng.responseRate}% response rate
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-4 py-2 bg-cyan-400/20 hover:bg-cyan-400/30 text-cyan-300 border border-cyan-400/30 rounded-lg transition-colors text-sm font-medium">
                      Continue Chat
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
