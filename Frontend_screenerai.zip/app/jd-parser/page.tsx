'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/layout/Sidebar'
import { Navbar } from '@/components/layout/Navbar'
import { Upload, FileText, Plus, X } from 'lucide-react'
import { JDParserStep } from '@/components/jd-parser/JDParserStep'
import { SkillsInput } from '@/components/jd-parser/SkillsInput'
import { CandidateMatchResults } from '@/components/jd-parser/CandidateMatchResults'

export default function JDParserPage() {
  const [step, setStep] = useState<'input' | 'parsing' | 'results'>('input')
  const [jobTitle, setJobTitle] = useState('')
  const [department, setDepartment] = useState('')
  const [yearsOfExperience, setYearsOfExperience] = useState('')
  const [jobDescription, setJobDescription] = useState('')
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const [skills, setSkills] = useState<string[]>([])
  const [skillInput, setSkillInput] = useState('')
  const [education, setEducation] = useState('')
  const [responsibilities, setResponsibilities] = useState<string[]>([])
  const [responsibilityInput, setResponsibilityInput] = useState('')
  const [parseResults, setParseResults] = useState<any>(null)
  const [matchedCandidates, setMatchedCandidates] = useState<any[]>([])

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    setUploadedFiles([...uploadedFiles, ...files])
  }

  const removeFile = (index: number) => {
    setUploadedFiles(uploadedFiles.filter((_, i) => i !== index))
  }

  const addSkill = () => {
    if (skillInput.trim()) {
      setSkills([...skills, skillInput.trim()])
      setSkillInput('')
    }
  }

  const removeSkill = (index: number) => {
    setSkills(skills.filter((_, i) => i !== index))
  }

  const addResponsibility = () => {
    if (responsibilityInput.trim()) {
      setResponsibilities([...responsibilities, responsibilityInput.trim()])
      setResponsibilityInput('')
    }
  }

  const removeResponsibility = (index: number) => {
    setResponsibilities(responsibilities.filter((_, i) => i !== index))
  }

  const handleParseJD = async () => {
    // Simulate parsing JD with AI
    const results = {
      role: jobTitle || 'Senior ML Engineer',
      experience: yearsOfExperience || '4+ years',
      skills: skills.length > 0 ? skills : ['Python', 'NLP', 'LLMs', 'Deep Learning', 'AWS', 'GCP'],
      responsibilities: responsibilities.length > 0 ? responsibilities : [
        'Design and develop ML models',
        'Work with cross-functional teams',
        'Optimize models for production',
        'Deploy and monitor systems',
      ],
      education: education || "Bachelor's / Master's in CS / AI",
      confidence: Math.random() * 30 + 70,
    }
    
    setParseResults(results)

    // Simulate finding matched candidates from uploaded resumes
    const candidates = [
      {
        id: 1,
        name: 'Arjun Mehta',
        match: 92,
        interest: 90,
        skills: ['Python', 'NLP', 'LLMs', 'AWS'],
        experience: '5 years',
        location: 'Bangalore, India',
        resume: 'arjun_mehta.pdf',
      },
      {
        id: 2,
        name: 'Neha Iyer',
        match: 88,
        interest: 85,
        skills: ['Python', 'NLP', 'Deep Learning', 'GCP'],
        experience: '4.5 years',
        location: 'Hyderabad, India',
        resume: 'neha_iyer.pdf',
      },
      {
        id: 3,
        name: 'Rohan Deshpande',
        match: 85,
        interest: 78,
        skills: ['Python', 'LLMs', 'Transformers', 'AWS'],
        experience: '4 years',
        location: 'Pune, India',
        resume: 'rohan_deshpande.pdf',
      },
      {
        id: 4,
        name: 'Sneha Kapoor',
        match: 82,
        interest: 75,
        skills: ['Python', 'Deep Learning', 'LLMs', 'AWS'],
        experience: '3.5 years',
        location: 'Gurgaon, India',
        resume: 'sneha_kapoor.pdf',
      },
    ]

    setMatchedCandidates(candidates)
    setStep('results')
  }

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <Navbar />

      <main className="ml-56 mt-16 p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">JD Parser</h1>
            <p className="text-gray-400">Upload resumes and parse job description to find the best matching candidates</p>
          </div>

          {step === 'input' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left Column: Upload & Basic Info */}
              <div className="lg:col-span-2 space-y-6">
                {/* File Upload Section */}
                <div className="glass-card-hover p-6">
                  <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                    <Upload className="w-5 h-5 text-cyan-400" />
                    Upload Resumes
                  </h2>
                  <p className="text-gray-400 text-sm mb-4">Upload PDF or DOC files to analyze candidate profiles</p>

                  <div className="border-2 border-dashed border-cyan-400/30 rounded-lg p-8 text-center hover:border-cyan-400/50 transition-colors cursor-pointer">
                    <input
                      type="file"
                      id="file-upload"
                      multiple
                      accept=".pdf,.doc,.docx"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <label htmlFor="file-upload" className="cursor-pointer">
                      <FileText className="w-12 h-12 text-cyan-400/50 mx-auto mb-3" />
                      <p className="text-white font-medium mb-1">Click to upload or drag and drop</p>
                      <p className="text-gray-400 text-sm">PDF, DOC, DOCX (Max 10MB each)</p>
                    </label>
                  </div>

                  {uploadedFiles.length > 0 && (
                    <div className="mt-6">
                      <h3 className="text-sm font-semibold text-gray-300 mb-3">Uploaded Files ({uploadedFiles.length})</h3>
                      <div className="space-y-2">
                        {uploadedFiles.map((file, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between bg-white/5 border border-white/10 rounded-lg p-3"
                          >
                            <div className="flex items-center gap-3">
                              <FileText className="w-4 h-4 text-cyan-400" />
                              <span className="text-sm text-gray-300">{file.name}</span>
                            </div>
                            <button
                              onClick={() => removeFile(idx)}
                              className="text-gray-400 hover:text-red-400 transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Job Description */}
                <div className="glass-card-hover p-6">
                  <h2 className="text-xl font-semibold text-white mb-4">Job Description</h2>
                  <textarea
                    value={jobDescription}
                    onChange={(e) => setJobDescription(e.target.value)}
                    placeholder="Paste the full job description here..."
                    className="w-full bg-white/5 border border-white/10 rounded-lg p-4 text-white placeholder-gray-500 focus:border-cyan-400 focus:outline-none min-h-48 resize-none"
                  />
                </div>

                {/* Basic Info */}
                <div className="glass-card-hover p-6">
                  <h2 className="text-xl font-semibold text-white mb-4">Job Information</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Job Title</label>
                      <input
                        type="text"
                        value={jobTitle}
                        onChange={(e) => setJobTitle(e.target.value)}
                        placeholder="e.g., Senior Machine Learning Engineer"
                        className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:border-cyan-400 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">Department</label>
                      <input
                        type="text"
                        value={department}
                        onChange={(e) => setDepartment(e.target.value)}
                        placeholder="e.g., Engineering"
                        className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:border-cyan-400 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-300 mb-2">Years of Experience Required</label>
                    <input
                      type="text"
                      value={yearsOfExperience}
                      onChange={(e) => setYearsOfExperience(e.target.value)}
                      placeholder="e.g., 4+ years"
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:border-cyan-400 focus:outline-none"
                    />
                  </div>

                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-300 mb-2">Education Required</label>
                    <input
                      type="text"
                      value={education}
                      onChange={(e) => setEducation(e.target.value)}
                      placeholder="e.g., Bachelor's / Master's in Computer Science"
                      className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:border-cyan-400 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Right Column: Skills & Responsibilities */}
              <div className="space-y-6">
                {/* Required Skills */}
                <div className="glass-card-hover p-6">
                  <h2 className="text-xl font-semibold text-white mb-4">Required Skills</h2>
                  <div className="flex gap-2 mb-3">
                    <input
                      type="text"
                      value={skillInput}
                      onChange={(e) => setSkillInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && addSkill()}
                      placeholder="Add a skill..."
                      className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:border-cyan-400 focus:outline-none text-sm"
                    />
                    <button
                      onClick={addSkill}
                      className="bg-cyan-400/20 hover:bg-cyan-400/30 text-cyan-300 border border-cyan-400/30 rounded-lg px-3 py-2 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-2">
                    {skills.map((skill, idx) => (
                      <div key={idx} className="flex items-center justify-between bg-cyan-400/10 border border-cyan-400/20 rounded-lg px-3 py-2">
                        <span className="text-sm text-cyan-300">{skill}</span>
                        <button
                          onClick={() => removeSkill(idx)}
                          className="text-cyan-300/50 hover:text-red-400 transition-colors"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Key Responsibilities */}
                <div className="glass-card-hover p-6">
                  <h2 className="text-xl font-semibold text-white mb-4">Key Responsibilities</h2>
                  <div className="flex gap-2 mb-3">
                    <input
                      type="text"
                      value={responsibilityInput}
                      onChange={(e) => setResponsibilityInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && addResponsibility()}
                      placeholder="Add responsibility..."
                      className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-white placeholder-gray-500 focus:border-cyan-400 focus:outline-none text-sm"
                    />
                    <button
                      onClick={addResponsibility}
                      className="bg-cyan-400/20 hover:bg-cyan-400/30 text-cyan-300 border border-cyan-400/30 rounded-lg px-3 py-2 transition-colors"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-2">
                    {responsibilities.map((resp, idx) => (
                      <div key={idx} className="flex items-center justify-between bg-teal-400/10 border border-teal-400/20 rounded-lg px-3 py-2">
                        <span className="text-sm text-teal-300">{resp}</span>
                        <button
                          onClick={() => removeResponsibility(idx)}
                          className="text-teal-300/50 hover:text-red-400 transition-colors"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Button */}
                <button
                  onClick={handleParseJD}
                  disabled={!jobDescription || uploadedFiles.length === 0}
                  className="w-full bg-gradient-to-r from-cyan-400 to-teal-400 hover:from-cyan-500 hover:to-teal-500 disabled:from-gray-600 disabled:to-gray-600 text-black font-semibold py-3 rounded-lg transition-all duration-200 disabled:cursor-not-allowed"
                >
                  Parse JD & Find Matches
                </button>
              </div>
            </div>
          )}

          {step === 'results' && matchedCandidates.length > 0 && (
            <CandidateMatchResults
              parseResults={parseResults}
              candidates={matchedCandidates}
              onBack={() => setStep('input')}
            />
          )}
        </div>
      </main>
    </div>
  )
}
