import { Sidebar } from '@/components/layout/Sidebar'
import { Navbar } from '@/components/layout/Navbar'
import { recentJobs } from '@/lib/data'
import { Plus, Search } from 'lucide-react'

export default function JobsPage() {
  const statusConfig: Record<string, { badge: string; color: string }> = {
    'Shortlist Ready': { badge: 'status-shortlist', color: 'text-cyan-300' },
    Engagement: { badge: 'status-engagement', color: 'text-teal-300' },
    Discovery: { badge: 'status-discovery', color: 'text-blue-300' },
    'JD Parsing': { badge: 'status-parsing', color: 'text-purple-300' },
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Layout */}
      <Sidebar />
      <Navbar />

      {/* Main content */}
      <main className="ml-56 mt-16 p-6">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">Job Descriptions</h2>
            <p className="text-gray-400">Manage your job postings and track candidate pipelines</p>
          </div>
          <button className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-400 to-teal-400 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/30 transition-all">
            <Plus className="w-5 h-5" />
            Add Job
          </button>
        </div>

        {/* Search */}
        <div className="mb-6 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
          <input
            type="text"
            placeholder="Search jobs..."
            className="w-full bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 py-3 text-gray-300 placeholder-gray-600 focus:outline-none focus:border-cyan-400/50 focus:bg-white/10 transition-all"
          />
        </div>

        {/* Jobs Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {recentJobs.map((job) => {
            const config = statusConfig[job.status] || statusConfig['Discovery']
            return (
              <div key={job.id} className="glass-card-hover p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-white mb-2">{job.title}</h3>
                    <p className={`text-xs font-semibold inline-flex items-center gap-1 status-shortlist`}>
                      {job.status === 'Shortlist Ready' && (
                        <>
                          <span className="w-2 h-2 bg-cyan-400 rounded-full"></span>
                          {job.status}
                        </>
                      )}
                      {job.status === 'Engagement' && (
                        <>
                          <span className="w-2 h-2 bg-teal-400 rounded-full"></span>
                          {job.status}
                        </>
                      )}
                      {job.status === 'Discovery' && (
                        <>
                          <span className="w-2 h-2 bg-blue-400 rounded-full"></span>
                          {job.status}
                        </>
                      )}
                      {job.status === 'JD Parsing' && (
                        <>
                          <span className="w-2 h-2 bg-purple-400 rounded-full"></span>
                          {job.status}
                        </>
                      )}
                    </p>
                  </div>
                </div>

                {/* Stats */}
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                    <p className="text-xs text-gray-500 mb-1">Candidates</p>
                    <p className="text-lg font-bold text-cyan-400">{job.candidatesCount}</p>
                  </div>
                  <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                    <p className="text-xs text-gray-500 mb-1">Response</p>
                    <p className="text-lg font-bold text-teal-400">{job.responseRate}%</p>
                  </div>
                  <div className="p-3 bg-white/5 rounded-lg border border-white/10">
                    <p className="text-xs text-gray-500 mb-1">Shortlist</p>
                    <p className="text-lg font-bold text-purple-400">{job.shortlistCount}</p>
                  </div>
                </div>

                {/* Updated */}
                <p className="text-xs text-gray-500 mb-4">Updated {job.updated}</p>

                {/* Action */}
                <button className="w-full px-4 py-2 bg-cyan-400/20 text-cyan-300 border border-cyan-400/30 rounded-lg hover:bg-cyan-400/30 transition-colors text-sm font-semibold">
                  View Details
                </button>
              </div>
            )
          })}
        </div>
      </main>
    </div>
  )
}
