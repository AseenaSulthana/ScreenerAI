import { Sidebar } from '@/components/layout/Sidebar'
import { Navbar } from '@/components/layout/Navbar'
import { candidates } from '@/lib/data'
import { MessageCircle, Plus, MapPin, Briefcase, Search, Filter } from 'lucide-react'

export default function CandidatesPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Layout */}
      <Sidebar />
      <Navbar />

      {/* Main content */}
      <main className="ml-56 mt-16 p-6">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold text-white mb-2">Candidates</h2>
            <p className="text-gray-400">Browse and manage discovered candidates</p>
          </div>
        </div>

        {/* Search & Filters */}
        <div className="mb-6 flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="text"
              placeholder="Search candidates..."
              className="w-full bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 py-3 text-gray-300 placeholder-gray-600 focus:outline-none focus:border-cyan-400/50 focus:bg-white/10 transition-all"
            />
          </div>
          <button className="flex items-center gap-2 px-6 py-3 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors">
            <Filter className="w-5 h-5 text-cyan-400" />
            Filters
          </button>
        </div>

        {/* Candidates Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {candidates.map((candidate) => (
            <div key={candidate.id} className="glass-card-hover p-6 flex flex-col h-full">
              {/* Header with avatar and match score */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start gap-3 flex-1">
                  <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400 to-teal-400 flex items-center justify-center text-xl flex-shrink-0">
                    {candidate.image}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-white font-semibold text-sm truncate">{candidate.name}</h4>
                    <p className="text-xs text-gray-400 mt-1 truncate">{candidate.role}</p>
                  </div>
                </div>
                {/* Match Score Circle */}
                <div className="flex flex-col items-center flex-shrink-0 ml-2">
                  <div className="w-10 h-10 rounded-full bg-cyan-400/20 border border-cyan-400/50 flex items-center justify-center">
                    <span className="text-sm font-bold text-cyan-400">{candidate.matchScore}%</span>
                  </div>
                  <span className="text-xs text-cyan-300 mt-1">Match</span>
                </div>
              </div>

              {/* Details */}
              <div className="space-y-2 mb-4 flex-1">
                <div className="flex items-center gap-2 text-xs text-gray-400">
                  <Briefcase className="w-3 h-3 flex-shrink-0" />
                  <span>{candidate.experience}</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-gray-400">
                  <MapPin className="w-3 h-3 flex-shrink-0" />
                  <span>{candidate.location}</span>
                </div>
              </div>

              {/* Skills */}
              <div className="mb-4">
                <p className="text-xs text-gray-500 mb-2">Top Skills</p>
                <div className="flex flex-wrap gap-1">
                  {candidate.skills.slice(0, 3).map((skill, idx) => (
                    <span key={idx} className="text-xs px-2 py-1 bg-white/5 border border-white/10 rounded text-gray-300">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Interest Score */}
              <div className="mb-4 p-3 bg-white/5 rounded-lg border border-white/10">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-400">Interest Score</span>
                  <span className="text-sm font-bold text-teal-400">{candidate.interestScore}%</span>
                </div>
                <div className="w-full h-1 bg-white/10 rounded-full mt-2 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-teal-400 to-cyan-400"
                    style={{ width: `${candidate.interestScore}%` }}
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <button className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-teal-400/20 text-teal-300 border border-teal-400/30 rounded-lg hover:bg-teal-400/30 transition-colors text-xs font-semibold">
                  <MessageCircle className="w-4 h-4" />
                  Engage
                </button>
                <button className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-cyan-400/20 text-cyan-300 border border-cyan-400/30 rounded-lg hover:bg-cyan-400/30 transition-colors text-xs font-semibold">
                  <Plus className="w-4 h-4" />
                  Save
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
