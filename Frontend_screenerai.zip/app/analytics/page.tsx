'use client'

import { Sidebar } from '@/components/layout/Sidebar'
import { Navbar } from '@/components/layout/Navbar'
import { TrendingUp, Users, Clock, Target } from 'lucide-react'

export default function AnalyticsPage() {
  const metrics = [
    {
      label: 'Total Candidates Sourced',
      value: '1,242',
      trend: '+12%',
      positive: true,
      icon: Users,
    },
    {
      label: 'Avg Response Time',
      value: '2.4h',
      trend: '-8%',
      positive: true,
      icon: Clock,
    },
    {
      label: 'Conversion Rate',
      value: '34%',
      trend: '+5%',
      positive: true,
      icon: Target,
    },
    {
      label: 'Engagement Score',
      value: '8.2/10',
      trend: '+2.1%',
      positive: true,
      icon: TrendingUp,
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <Navbar />

      <main className="ml-56 mt-16 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">Analytics</h1>
            <p className="text-gray-400">Recruitment metrics and insights</p>
          </div>

          {/* KPI Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {metrics.map((metric, idx) => {
              const Icon = metric.icon
              return (
                <div key={idx} className="glass-card-hover p-6">
                  <div className="flex items-start justify-between mb-4">
                    <Icon className="w-8 h-8 text-cyan-400" />
                    <span className={`text-sm font-semibold ${metric.positive ? 'text-green-400' : 'text-red-400'}`}>
                      {metric.trend}
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm mb-2">{metric.label}</p>
                  <p className="text-3xl font-bold text-white">{metric.value}</p>
                </div>
              )
            })}
          </div>

          {/* Charts Placeholder */}
          <div className="glass-card-hover p-8 text-center">
            <p className="text-gray-400 mb-4">Advanced analytics charts coming soon</p>
            <p className="text-sm text-gray-500">Recruitment funnel, source analysis, time-to-hire metrics, and more</p>
          </div>
        </div>
      </main>
    </div>
  )
}
