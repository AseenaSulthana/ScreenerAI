'use client'

import { Sidebar } from '@/components/layout/Sidebar'
import { Navbar } from '@/components/layout/Navbar'
import { CheckCircle, AlertCircle, Settings } from 'lucide-react'

export default function IntegrationsPage() {
  const integrations = [
    {
      name: 'Workday',
      description: 'ATS and HR system integration',
      status: 'connected',
      icon: '📊',
    },
    {
      name: 'LinkedIn Recruiter',
      description: 'Talent sourcing and candidate profiles',
      status: 'connected',
      icon: '💼',
    },
    {
      name: 'Gmail',
      description: 'Email communication tracking',
      status: 'connected',
      icon: '📧',
    },
    {
      name: 'Slack',
      description: 'Notifications and alerts',
      status: 'disconnected',
      icon: '💬',
    },
    {
      name: 'Microsoft Teams',
      description: 'Team communication',
      status: 'disconnected',
      icon: '👥',
    },
    {
      name: 'Greenhouse',
      description: 'Applicant tracking system',
      status: 'disconnected',
      icon: '🌿',
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <Navbar />

      <main className="ml-56 mt-16 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">ATS Integrations</h1>
            <p className="text-gray-400">Connect your recruitment tools and systems</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {integrations.map((integration, idx) => (
              <div key={idx} className="glass-card-hover p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="text-3xl">{integration.icon}</div>
                  {integration.status === 'connected' ? (
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-gray-500" />
                  )}
                </div>
                <h3 className="text-lg font-semibold text-white mb-1">{integration.name}</h3>
                <p className="text-sm text-gray-400 mb-4">{integration.description}</p>
                <button className={`w-full py-2 rounded-lg font-medium transition-colors text-sm ${
                  integration.status === 'connected'
                    ? 'bg-gray-600/30 hover:bg-gray-600/50 text-gray-300'
                    : 'bg-cyan-400/20 hover:bg-cyan-400/30 text-cyan-300 border border-cyan-400/30'
                }`}>
                  {integration.status === 'connected' ? 'Configured' : 'Connect'}
                </button>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}
