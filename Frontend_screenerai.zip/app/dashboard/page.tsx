import { ProtectedLayout } from '@/components/layout/ProtectedLayout'
import { StatCard } from '@/components/dashboard/StatCard'
import { PipelineTracker } from '@/components/dashboard/PipelineTracker'
import { TopPerformingJob } from '@/components/dashboard/TopPerformingJob'
import { RecentJobsTable } from '@/components/dashboard/RecentJobsTable'
import { AIInsights } from '@/components/dashboard/AIInsights'
import { dashboardStats } from '@/lib/data'

export default function Dashboard() {
  return (
    <ProtectedLayout>
      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-2">Dashboard Overview</h2>
          <p className="text-gray-400">Welcome back, Rohit! Here&apos;s what&apos;s happening today.</p>
        </div>

        {/* KPI Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <StatCard
            label="Active Jobs"
            value={dashboardStats.activeJobs.value}
            change={dashboardStats.activeJobs.change}
            unit={dashboardStats.activeJobs.unit}
            icon="📋"
          />
          <StatCard
            label="Candidates Discovered"
            value={dashboardStats.candidatesDiscovered.value}
            change={dashboardStats.candidatesDiscovered.change}
            unit={dashboardStats.candidatesDiscovered.unit}
            icon="👥"
          />
          <StatCard
            label="Conversations"
            value={dashboardStats.conversations.value}
            change={dashboardStats.conversations.change}
            unit={dashboardStats.conversations.unit}
            icon="💬"
          />
          <StatCard
            label="Avg. Response Rate"
            value={`${dashboardStats.avgResponseRate.value}%`}
            change={dashboardStats.avgResponseRate.change}
            unit={dashboardStats.avgResponseRate.unit}
            icon="📊"
          />
          <StatCard
            label="Shortlists Ready"
            value={dashboardStats.shortlistsReady.value}
            change={dashboardStats.shortlistsReady.change}
            unit={dashboardStats.shortlistsReady.unit}
            icon="✅"
          />
        </div>

        {/* Pipeline & Top Job */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <PipelineTracker />
          <TopPerformingJob />
        </div>

        {/* Table & Insights */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <RecentJobsTable />
          <AIInsights />
        </div>
      </div>
    </ProtectedLayout>
  )
}
