'use client'

import { CheckCircle, AlertCircle } from 'lucide-react'

interface JDParserStepProps {
  data: {
    role: string
    experience: string
    skills: string[]
    responsibilities: string[]
    education: string
    confidence: number
  }
}

export function JDParserStep({ data }: JDParserStepProps) {
  return (
    <div className="space-y-6">
      <div className="glass-card-hover p-6">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-green-400" />
          JD Parsing Complete
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Role */}
          <div>
            <p className="text-sm text-gray-400 mb-2">Role</p>
            <p className="text-lg font-medium text-cyan-300">{data.role}</p>
            <div className="mt-2 h-1 bg-white/10 rounded-full overflow-hidden">
              <div className="h-full w-11/12 bg-green-400"></div>
            </div>
            <p className="text-xs text-gray-500 mt-1">98% Confidence</p>
          </div>

          {/* Experience */}
          <div>
            <p className="text-sm text-gray-400 mb-2">Experience</p>
            <p className="text-lg font-medium text-cyan-300">{data.experience}</p>
            <div className="mt-2 h-1 bg-white/10 rounded-full overflow-hidden">
              <div className="h-full w-5/6 bg-green-400"></div>
            </div>
            <p className="text-xs text-gray-500 mt-1">96% Confidence</p>
          </div>
        </div>

        {/* Skills */}
        <div className="mt-6">
          <p className="text-sm text-gray-400 mb-3">Top Skills</p>
          <div className="flex flex-wrap gap-2">
            {data.skills.map((skill, idx) => (
              <div key={idx} className="bg-cyan-400/10 border border-cyan-400/30 px-3 py-1 rounded-full">
                <p className="text-xs font-medium text-cyan-300">{skill}</p>
                <p className="text-xs text-gray-500">{95 - idx * 3}%</p>
              </div>
            ))}
          </div>
        </div>

        {/* Education */}
        <div className="mt-6">
          <p className="text-sm text-gray-400 mb-2">Education</p>
          <p className="text-white">{data.education}</p>
        </div>
      </div>
    </div>
  )
}
