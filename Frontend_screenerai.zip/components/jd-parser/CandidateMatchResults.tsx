'use client'

import { ArrowLeft, Mail, Download, Star, MessageCircle } from 'lucide-react'

interface CandidateMatchResultsProps {
  parseResults: any
  candidates: any[]
  onBack: () => void
}

export function CandidateMatchResults({ parseResults, candidates, onBack }: CandidateMatchResultsProps) {
  return (
    <div className="space-y-6">
      {/* Back Button & Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors mb-3"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Editor
          </button>
          <h2 className="text-3xl font-bold text-white">Matched Candidates</h2>
          <p className="text-gray-400 mt-1">Found {candidates.length} candidates matching your JD</p>
        </div>
      </div>

      {/* JD Summary Card */}
      <div className="glass-card-hover p-6">
        <h3 className="text-lg font-semibold text-white mb-4">Job Details Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-sm text-gray-400 mb-1">Role</p>
            <p className="text-white font-medium">{parseResults.role}</p>
          </div>
          <div>
            <p className="text-sm text-gray-400 mb-1">Experience</p>
            <p className="text-white font-medium">{parseResults.experience}</p>
          </div>
          <div>
            <p className="text-sm text-gray-400 mb-1">Education</p>
            <p className="text-white font-medium text-sm">{parseResults.education}</p>
          </div>
          <div>
            <p className="text-sm text-gray-400 mb-1">Confidence</p>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-cyan-400/20 border border-cyan-400 flex items-center justify-center">
                <span className="text-xs font-bold text-cyan-300">{Math.round(parseResults.confidence)}</span>
              </div>
              <span className="text-white text-sm">%</span>
            </div>
          </div>
        </div>
        <div className="mt-4">
          <p className="text-sm text-gray-400 mb-2">Required Skills</p>
          <div className="flex flex-wrap gap-2">
            {parseResults.skills.map((skill: string, idx: number) => (
              <span key={idx} className="bg-cyan-400/10 border border-cyan-400/30 text-cyan-300 px-3 py-1 rounded-full text-sm">
                {skill}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Candidates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {candidates.map((candidate) => (
          <div key={candidate.id} className="glass-card-hover p-6">
            {/* Header */}
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h4 className="text-lg font-semibold text-white mb-1">{candidate.name}</h4>
                <p className="text-sm text-gray-400">{candidate.experience} experience</p>
              </div>
              <button className="text-gray-400 hover:text-yellow-400 transition-colors">
                <Star className="w-5 h-5" />
              </button>
            </div>

            {/* Match Scores */}
            <div className="grid grid-cols-2 gap-4 mb-4 pb-4 border-b border-white/10">
              <div>
                <p className="text-xs text-gray-500 mb-2">Match Score</p>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-400 to-teal-400"
                      style={{ width: `${candidate.match}%` }}
                    />
                  </div>
                  <span className="text-lg font-bold text-cyan-300">{candidate.match}%</span>
                </div>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-2">Interest Score</p>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-teal-400 to-cyan-400"
                      style={{ width: `${candidate.interest}%` }}
                    />
                  </div>
                  <span className="text-lg font-bold text-teal-300">{candidate.interest}%</span>
                </div>
              </div>
            </div>

            {/* Skills */}
            <div className="mb-4">
              <p className="text-xs text-gray-400 mb-2">Relevant Skills</p>
              <div className="flex flex-wrap gap-1.5">
                {candidate.skills.map((skill: string, idx: number) => (
                  <span key={idx} className="bg-cyan-400/15 text-cyan-300 px-2 py-1 rounded text-xs">
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            {/* Location */}
            <div className="mb-4 pb-4 border-b border-white/10">
              <p className="text-xs text-gray-400 mb-1">Location</p>
              <p className="text-sm text-white">{candidate.location}</p>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button className="flex-1 flex items-center justify-center gap-2 bg-cyan-400/20 hover:bg-cyan-400/30 text-cyan-300 border border-cyan-400/30 rounded-lg py-2 transition-colors text-sm font-medium">
                <MessageCircle className="w-4 h-4" />
                Engage
              </button>
              <button className="flex-1 flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 text-gray-300 border border-white/10 rounded-lg py-2 transition-colors text-sm font-medium">
                <Download className="w-4 h-4" />
                Resume
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Bottom Actions */}
      <div className="flex gap-4 pt-6 border-t border-white/10">
        <button
          onClick={onBack}
          className="px-6 py-3 bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded-lg font-medium transition-colors"
        >
          Modify JD
        </button>
        <button className="px-6 py-3 bg-gradient-to-r from-cyan-400 to-teal-400 hover:from-cyan-500 hover:to-teal-500 text-black rounded-lg font-medium transition-all">
          Sync to ATS
        </button>
        <button className="px-6 py-3 bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded-lg font-medium transition-colors ml-auto">
          Export Results
        </button>
      </div>
    </div>
  )
}
