'use client'

import { Plus, X } from 'lucide-react'

interface SkillsInputProps {
  skills: string[]
  onAdd: (skill: string) => void
  onRemove: (index: number) => void
}

export function SkillsInput({ skills, onAdd, onRemove }: SkillsInputProps) {
  const suggestedSkills = [
    'Python', 'JavaScript', 'TypeScript', 'React', 'Node.js',
    'SQL', 'MongoDB', 'AWS', 'Docker', 'Kubernetes',
    'Machine Learning', 'Data Science', 'NLP', 'Deep Learning'
  ]

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white">Required Skills</h3>

      <div className="flex flex-wrap gap-2">
        {suggestedSkills.map((skill) => (
          <button
            key={skill}
            onClick={() => !skills.includes(skill) && onAdd(skill)}
            disabled={skills.includes(skill)}
            className={`px-3 py-2 rounded-lg text-sm font-medium transition-all ${
              skills.includes(skill)
                ? 'bg-cyan-400/30 border border-cyan-400 text-cyan-300'
                : 'bg-white/5 border border-white/10 text-gray-400 hover:border-cyan-400/50'
            }`}
          >
            {skill}
          </button>
        ))}
      </div>

      {skills.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm text-gray-400">Selected Skills ({skills.length})</p>
          <div className="space-y-2">
            {skills.map((skill, idx) => (
              <div
                key={idx}
                className="flex items-center justify-between bg-cyan-400/10 border border-cyan-400/20 rounded-lg px-3 py-2"
              >
                <span className="text-sm text-cyan-300">{skill}</span>
                <button
                  onClick={() => onRemove(idx)}
                  className="text-gray-400 hover:text-red-400 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
