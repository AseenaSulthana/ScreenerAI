'use client'

import { candidates } from '@/lib/data'
import { CandidateCard } from './CandidateCard'
import { Search, Filter } from 'lucide-react'
import { useState } from 'react'

interface CandidateDiscoveryProps {
  onNext?: () => void
}

export function CandidateDiscovery({ onNext }: CandidateDiscoveryProps) {
  const [searchTerm, setSearchTerm] = useState('')

  const filteredCandidates = candidates.filter((c) =>
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.role.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-semibold text-white mb-2">3. Candidate Discovery</h3>
        <p className="text-gray-400">Search candidates...</p>
      </div>

      {/* Search & Filters */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
          <input
            type="text"
            placeholder="Search candidates..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-lg pl-12 pr-4 py-3 text-gray-300 placeholder-gray-600 focus:outline-none focus:border-cyan-400/50 focus:bg-white/10 transition-all"
          />
        </div>
        <button className="flex items-center gap-2 px-6 py-3 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors">
          <Filter className="w-5 h-5 text-cyan-400" />
          Filters
        </button>
      </div>

      {/* Candidates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredCandidates.map((candidate) => (
          <CandidateCard key={candidate.id} candidate={candidate} />
        ))}
      </div>

      {/* Action Button */}
      <div className="flex justify-end">
        <button
          onClick={onNext}
          className="px-6 py-3 bg-gradient-to-r from-cyan-400 to-teal-400 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/30 transition-all duration-300"
        >
          Engage with Candidates
        </button>
      </div>
    </div>
  )
}
