'use client'

import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts'
import { candidates } from '@/lib/data'

export function ScatterPlot() {
  // Transform candidate data for scatter plot
  const data = candidates.map((c) => ({
    name: c.name,
    matchScore: c.matchScore,
    interestScore: c.interestScore,
  }))

  return (
    <div className="glass-card-hover p-6">
      <h4 className="text-lg font-semibold text-white mb-6">Shortlist (Ranked)</h4>

      <ResponsiveContainer width="100%" height={300}>
        <ScatterChart margin={{ top: 20, right: 20, bottom: 60, left: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1A4949" />
          <XAxis
            type="number"
            dataKey="matchScore"
            name="Match Score"
            stroke="#7FC4C4"
            label={{ value: 'Match Score', position: 'bottom', offset: 10, fill: '#7FC4C4' }}
          />
          <YAxis
            type="number"
            dataKey="interestScore"
            name="Interest Score"
            stroke="#7FC4C4"
            label={{ value: 'Interest Score', angle: -90, position: 'insideLeft', fill: '#7FC4C4' }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#0B2F2F',
              border: '1px solid #1A4949',
              borderRadius: '8px',
            }}
            labelStyle={{ color: '#E8F4F4' }}
            cursor={{ strokeDasharray: '3 3' }}
          />
          <Legend wrapperStyle={{ paddingTop: '20px' }} />
          <Scatter
            name="Candidates"
            data={data}
            fill="#00FFC6"
            shape="circle"
          />
        </ScatterChart>
      </ResponsiveContainer>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 mt-6">
        <div className="p-3 bg-white/5 rounded-lg border border-white/10">
          <p className="text-xs text-gray-500 mb-1">Top Match</p>
          <p className="text-sm font-bold text-cyan-400">{Math.max(...candidates.map(c => c.matchScore))}%</p>
        </div>
        <div className="p-3 bg-white/5 rounded-lg border border-white/10">
          <p className="text-xs text-gray-500 mb-1">Avg Interest</p>
          <p className="text-sm font-bold text-teal-400">
            {Math.round(candidates.reduce((a, b) => a + b.interestScore, 0) / candidates.length)}%
          </p>
        </div>
      </div>
    </div>
  )
}
