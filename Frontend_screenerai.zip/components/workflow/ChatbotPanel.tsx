'use client'

import { engagementConversation } from '@/lib/data'
import { Send } from 'lucide-react'
import { useState } from 'react'

interface ChatbotPanelProps {
  onNext?: () => void
}

export function ChatbotPanel({ onNext }: ChatbotPanelProps) {
  const [message, setMessage] = useState('')

  const handleSend = () => {
    if (message.trim()) {
      setMessage('')
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-semibold text-white mb-2">4. Engagement</h3>
        <p className="text-gray-400">AI-Powered Conversation</p>
      </div>

      {/* Chat Container */}
      <div className="glass-card-hover p-6 flex flex-col h-96">
        {/* Messages */}
        <div className="flex-1 space-y-4 overflow-y-auto mb-4">
          {engagementConversation.map((msg, index) => (
            <div key={index} className={`flex ${msg.role === 'ai' ? 'justify-start' : 'justify-end'}`}>
              <div
                className={`max-w-xs rounded-lg px-4 py-3 ${
                  msg.role === 'ai'
                    ? 'bg-cyan-400/20 border border-cyan-400/30 text-cyan-100'
                    : 'bg-teal-400/20 border border-teal-400/30 text-teal-100'
                }`}
              >
                <p className="text-sm">{msg.message}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Input */}
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Type your message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            className="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-gray-300 placeholder-gray-600 focus:outline-none focus:border-cyan-400/50 focus:bg-white/10 transition-all text-sm"
          />
          <button
            onClick={handleSend}
            className="p-2 bg-cyan-400/20 text-cyan-300 border border-cyan-400/30 rounded-lg hover:bg-cyan-400/30 transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Action Button */}
      <div className="flex justify-end">
        <button
          onClick={onNext}
          className="px-6 py-3 bg-gradient-to-r from-cyan-400 to-teal-400 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/30 transition-all duration-300"
        >
          View Shortlist
        </button>
      </div>
    </div>
  )
}
