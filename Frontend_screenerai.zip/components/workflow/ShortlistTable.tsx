import { shortlistCandidates } from '@/lib/data'
import { Eye, Send, Star, MoreVertical } from 'lucide-react'

interface ShortlistTableProps {
  onComplete?: () => void
}

export function ShortlistTable({ onComplete }: ShortlistTableProps) {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-semibold text-white mb-2">5. Shortlist (Ranked)</h3>
        <p className="text-gray-400">Match Score & Interest Score</p>
      </div>

      {/* Table */}
      <div className="glass-card-hover p-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/10">
              <th className="text-left py-3 px-4 text-gray-500 font-medium">Rank</th>
              <th className="text-left py-3 px-4 text-gray-500 font-medium">Candidate</th>
              <th className="text-right py-3 px-4 text-gray-500 font-medium">Match Score</th>
              <th className="text-right py-3 px-4 text-gray-500 font-medium">Interest Score</th>
              <th className="text-left py-3 px-4 text-gray-500 font-medium">Summary</th>
              <th className="text-center py-3 px-4 text-gray-500 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {shortlistCandidates.map((candidate) => (
              <tr key={candidate.rank} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                <td className="py-3 px-4">
                  <div className="w-8 h-8 rounded-full bg-cyan-400/20 border border-cyan-400/30 flex items-center justify-center">
                    <span className="text-sm font-bold text-cyan-400">{candidate.rank}</span>
                  </div>
                </td>
                <td className="py-3 px-4 text-white font-semibold">{candidate.name}</td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <div className="w-16 h-2 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-cyan-400 to-teal-400 rounded-full"
                        style={{ width: `${candidate.matchScore}%` }}
                      />
                    </div>
                    <span className="font-bold text-cyan-400 w-8 text-right">{candidate.matchScore}%</span>
                  </div>
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <div className="w-16 h-2 bg-white/10 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-teal-400 to-cyan-400 rounded-full"
                        style={{ width: `${candidate.interestScore}%` }}
                      />
                    </div>
                    <span className="font-bold text-teal-400 w-8 text-right">{candidate.interestScore}%</span>
                  </div>
                </td>
                <td className="py-3 px-4 text-gray-400 text-xs">{candidate.summary}</td>
                <td className="py-3 px-4">
                  <div className="flex items-center justify-center gap-2">
                    <button className="p-1.5 hover:bg-white/10 rounded transition-colors text-gray-400 hover:text-cyan-400">
                      <Eye className="w-4 h-4" />
                    </button>
                    <button className="p-1.5 hover:bg-white/10 rounded transition-colors text-gray-400 hover:text-teal-400">
                      <Send className="w-4 h-4" />
                    </button>
                    <button className="p-1.5 hover:bg-white/10 rounded transition-colors text-gray-400 hover:text-yellow-400">
                      <Star className="w-4 h-4" />
                    </button>
                    <button className="p-1.5 hover:bg-white/10 rounded transition-colors text-gray-400 hover:text-cyan-400">
                      <MoreVertical className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Export button */}
      <div className="flex justify-between items-center">
        <div className="text-sm text-gray-400">
          <p>
            Top 4 candidates selected for {' '}
            <span className="font-semibold text-cyan-400">Senior Machine Learning Engineer</span>
          </p>
        </div>
        <div className="flex gap-3">
          <button className="px-6 py-2 bg-white/5 text-gray-300 border border-white/10 rounded-lg hover:bg-white/10 transition-colors font-semibold text-sm">
            Export Shortlist
          </button>
          <button
            onClick={onComplete}
            className="px-6 py-2 bg-gradient-to-r from-cyan-400 to-teal-400 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/30 transition-all duration-300 text-sm"
          >
            Sync to ATS
          </button>
        </div>
      </div>
    </div>
  )
}
