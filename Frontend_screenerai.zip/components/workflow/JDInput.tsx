'use client'

import { Upload, Zap } from 'lucide-react'
import { jobDescription } from '@/lib/data'
import { useState } from 'react'

interface JDInputProps {
  onNext?: () => void
}

export function JDInput({ onNext }: JDInputProps) {
  const [value, setValue] = useState(jobDescription)

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-semibold text-white mb-2">1. JD Input</h3>
        <p className="text-gray-400">Paste job description or upload file</p>
      </div>

      {/* Text Area */}
      <div className="glass-card-hover p-6">
        <textarea
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder="Paste your job description here..."
          className="w-full h-64 bg-white/5 border border-white/10 rounded-lg p-4 text-gray-200 placeholder-gray-600 focus:outline-none focus:border-cyan-400/50 focus:bg-white/10 resize-none transition-all"
        />
      </div>

      {/* Upload Option */}
      <div className="glass-card-hover p-6 border-2 border-dashed border-white/10 hover:border-cyan-400/30 transition-colors cursor-pointer">
        <div className="flex items-center justify-center gap-3 text-center">
          <Upload className="w-5 h-5 text-cyan-400" />
          <div>
            <p className="text-gray-300 font-semibold">Upload File</p>
            <p className="text-xs text-gray-500">Drag and drop or click to upload</p>
          </div>
        </div>
      </div>

      {/* Action Button */}
      <div className="flex justify-end">
        <button
          onClick={onNext}
          className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-400 to-teal-400 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/30 transition-all duration-300"
        >
          <Zap className="w-5 h-5" />
          Parse JD with AI
        </button>
      </div>
    </div>
  )
}
