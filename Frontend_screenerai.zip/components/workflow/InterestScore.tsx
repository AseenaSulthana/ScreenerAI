import { interestBreakdown } from '@/lib/data'

interface InterestScoreProps {
  score?: number
}

export function InterestScore({ score = 88 }: InterestScoreProps) {
  return (
    <div className="glass-card-hover p-8 text-center">
      <p className="text-gray-400 text-sm mb-4">Interest Score Breakdown</p>

      {/* Large Circular Progress */}
      <div className="relative w-32 h-32 mx-auto mb-8">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
          {/* Background circle */}
          <circle cx="50" cy="50" r="45" fill="none" stroke="#1A4949" strokeWidth="8" />
          {/* Progress circle */}
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="url(#gradient)"
            strokeWidth="8"
            strokeDasharray={`${(score / 100) * 283} 283`}
            strokeLinecap="round"
          />
          <defs>
            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00FFC6" />
              <stop offset="100%" stopColor="#00C2A8" />
            </linearGradient>
          </defs>
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <div>
            <p className="text-3xl font-bold text-cyan-400">{score}%</p>
            <p className="text-xs text-gray-500 mt-1">Interested</p>
          </div>
        </div>
      </div>

      {/* Breakdown */}
      <div className="space-y-2">
        {interestBreakdown.map((item, idx) => (
          <div key={idx} className="flex items-center justify-between text-sm">
            <span className="text-gray-400">{item.label}</span>
            <div className="flex items-center gap-2">
              <div className="w-24 h-2 bg-white/5 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${item.value}%`,
                    backgroundColor: item.color,
                  }}
                />
              </div>
              <span className="text-cyan-400 font-semibold w-10 text-right">{item.value}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
