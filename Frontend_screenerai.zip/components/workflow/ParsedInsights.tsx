import { parsedInsights } from '@/lib/data'
import { CheckCircle2 } from 'lucide-react'

interface ParsedInsightsProps {
  onNext?: () => void
}

export function ParsedInsights({ onNext }: ParsedInsightsProps) {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-semibold text-white mb-2">2. JD Parsing</h3>
        <p className="text-gray-400">AI Extracted Insights</p>
      </div>

      {/* Insights Cards */}
      <div className="space-y-3">
        {parsedInsights.map((insight, index) => (
          <div key={index} className="glass-card-hover p-4 flex items-start gap-4">
            <div className="flex-shrink-0">
              <CheckCircle2 className="w-5 h-5 text-green-400 mt-1" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-gray-500 mb-1">{insight.label}</p>
              <p className="text-white font-semibold">{insight.value}</p>
            </div>
            <div className="text-right flex-shrink-0">
              <div className="w-12 h-12 rounded-full flex items-center justify-center bg-green-400/20 border border-green-400/30">
                <span className="text-sm font-bold text-green-400">{insight.confidence}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Overall Match */}
      <div className="glass-card-hover p-6 bg-gradient-to-r from-green-400/10 to-teal-400/10 border-2 border-green-400/30">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-gray-400 text-sm mb-1">Overall JD Match Weightage</p>
            <p className="text-2xl font-bold text-green-400">92%</p>
          </div>
          <div className="text-5xl">✓</div>
        </div>
      </div>

      {/* Action Button */}
      <div className="flex justify-end">
        <button
          onClick={onNext}
          className="px-6 py-3 bg-gradient-to-r from-cyan-400 to-teal-400 text-black font-semibold rounded-lg hover:shadow-lg hover:shadow-cyan-500/30 transition-all duration-300"
        >
          Discover Candidates
        </button>
      </div>
    </div>
  )
}
