import { Candidate } from '@/lib/types'
import { MessageCircle, Plus, MapPin, Briefcase } from 'lucide-react'

interface CandidateCardProps {
  candidate: Candidate
}

export function CandidateCard({ candidate }: CandidateCardProps) {
  return (
    <div className="glass-card-hover p-5 flex flex-col h-full">
      {/* Header with avatar and match score */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400 to-teal-400 flex items-center justify-center text-xl">
            {candidate.image}
          </div>
          <div className="flex-1">
            <h4 className="text-white font-semibold text-sm">{candidate.name}</h4>
            <p className="text-xs text-gray-400 mt-1">{candidate.role}</p>
          </div>
        </div>
        {/* Match Score Circle */}
        <div className="flex flex-col items-center">
          <div className="w-10 h-10 rounded-full bg-cyan-400/20 border border-cyan-400/50 flex items-center justify-center">
            <span className="text-sm font-bold text-cyan-400">{candidate.matchScore}%</span>
          </div>
          <span className="text-xs text-cyan-300 mt-1">Match</span>
        </div>
      </div>

      {/* Details */}
      <div className="space-y-2 mb-4 flex-1">
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <Briefcase className="w-3 h-3 flex-shrink-0" />
          <span>{candidate.experience}</span>
        </div>
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <MapPin className="w-3 h-3 flex-shrink-0" />
          <span>{candidate.location}</span>
        </div>
      </div>

      {/* Skills */}
      <div className="mb-4">
        <p className="text-xs text-gray-500 mb-2">Top Skills</p>
        <div className="flex flex-wrap gap-1">
          {candidate.skills.map((skill, idx) => (
            <span key={idx} className="text-xs px-2 py-1 bg-white/5 border border-white/10 rounded text-gray-300">
              {skill}
            </span>
          ))}
        </div>
      </div>

      {/* Interest Score */}
      <div className="mb-4 p-3 bg-white/5 rounded-lg border border-white/10">
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-400">Interest Score</span>
          <div className="flex items-center gap-1">
            <span className="text-sm font-bold text-teal-400">{candidate.interestScore}%</span>
            <div className="w-6 h-6 rounded-full bg-teal-400/20 border border-teal-400/50 flex items-center justify-center">
              <span className="text-xs text-teal-300">→</span>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex gap-2">
        <button className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-teal-400/20 text-teal-300 border border-teal-400/30 rounded-lg hover:bg-teal-400/30 transition-colors text-xs font-semibold">
          <MessageCircle className="w-4 h-4" />
          Engage
        </button>
        <button className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-cyan-400/20 text-cyan-300 border border-cyan-400/30 rounded-lg hover:bg-cyan-400/30 transition-colors text-xs font-semibold">
          <Plus className="w-4 h-4" />
          Save
        </button>
      </div>
    </div>
  )
}
