'use client'

import { Home, FileText, Users, MessageCircle, CheckCircle, Settings, BarChart3, Zap } from 'lucide-react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

export function Sidebar() {
  const pathname = usePathname()

  const navItems = [
    { label: 'Dashboard', icon: Home, href: '/dashboard', id: 'dashboard' },
    { label: 'JD Parser', icon: Zap, href: '/jd-parser', id: 'jd-parser' },
    { label: 'Job Descriptions', icon: FileText, href: '/jobs', id: 'jobs' },
    { label: 'Candidates', icon: Users, href: '/candidates', id: 'candidates' },
    { label: 'Engagements', icon: MessageCircle, href: '/engagements', id: 'engagements' },
    { label: 'Shortlists', icon: CheckCircle, href: '/shortlists', id: 'shortlists' },
    { label: 'Analytics', icon: BarChart3, href: '/analytics', id: 'analytics' },
    { label: 'ATS Integrations', icon: Zap, href: '/integrations', id: 'integrations' },
    { label: 'Settings', icon: Settings, href: '/settings', id: 'settings' },
  ]

  return (
    <aside className="fixed left-0 top-0 h-screen w-56 glass-card border-r rounded-none bg-gradient-to-b from-[#0B2F2F] to-[#061A1A] p-6 flex flex-col">
      {/* Logo */}
      <div className="mb-8 text-center">
        <span className="font-bold text-cyan-400 text-lg block">Deccan</span>
        <span className="text-xs text-cyan-300">AI Experts</span>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1">
        {navItems.map((item) => {
          const isActive = pathname === item.href
          const Icon = item.icon
          return (
            <Link
              key={item.id}
              href={item.href}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive
                  ? 'bg-cyan-400/20 text-cyan-300 border border-cyan-400/30'
                  : 'text-gray-400 hover:text-cyan-300 hover:bg-white/5'
              }`}
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              <span className="text-sm font-medium">{item.label}</span>
            </Link>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="border-t border-white/10 pt-4">
        <div className="text-xs text-gray-500 text-center">
          <p className="font-semibold text-gray-400 mb-2">Rohit Sharma</p>
          <p>Recruiter</p>
        </div>
      </div>
    </aside>
  )
}
