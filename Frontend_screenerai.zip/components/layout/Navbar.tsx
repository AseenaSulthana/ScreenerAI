'use client'

import { Search, Bell, Settings } from 'lucide-react'

export function Navbar() {
  return (
    <header className="fixed left-56 right-0 top-0 h-16 glass-card border-b rounded-none bg-gradient-to-r from-[#0B2F2F] to-[#061A1A] px-6 flex items-center justify-between z-40">
      {/* Left: Title */}
      <div className="flex-1">
        <h1 className="text-lg font-semibold text-white">Dashboard Overview</h1>
        <p className="text-xs text-gray-400 mt-0.5">Welcome back, Rohit! Here&apos;s what&apos;s happening today.</p>
      </div>

      {/* Right: Search, Notifications, Settings */}
      <div className="flex items-center gap-4">
        {/* Search */}
        <div className="relative hidden md:flex">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Search candidates, jobs..."
            className="bg-white/5 border border-white/10 rounded-lg pl-10 pr-4 py-2 text-sm text-gray-300 placeholder-gray-500 focus:outline-none focus:border-cyan-400/50 focus:bg-white/10 transition-all"
          />
        </div>

        {/* Notifications */}
        <button className="relative p-2 text-gray-400 hover:text-cyan-400 transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </button>

        {/* Settings */}
        <button className="p-2 text-gray-400 hover:text-cyan-400 transition-colors">
          <Settings className="w-5 h-5" />
        </button>
      </div>
    </header>
  )
}
