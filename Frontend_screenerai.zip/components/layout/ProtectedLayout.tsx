import { Sidebar } from './Sidebar'
import { Navbar } from './Navbar'

interface ProtectedLayoutProps {
  children: React.ReactNode
}

export function ProtectedLayout({ children }: ProtectedLayoutProps) {
  return (
    <div className="min-h-screen bg-background">
      <Sidebar />
      <Navbar />
      <main className="ml-56 mt-16">
        {children}
      </main>
    </div>
  )
}
