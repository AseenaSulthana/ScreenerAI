import { TrendingUp } from 'lucide-react'

interface StatCardProps {
  label: string
  value: number | string
  change: number
  unit: string
  icon?: React.ReactNode
}

export function StatCard({ label, value, change, unit, icon }: StatCardProps) {
  return (
    <div className="glass-card-hover p-6">
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="text-sm text-gray-400 mb-1">{label}</p>
          <p className="text-3xl font-bold text-white">{value}</p>
        </div>
        {icon && <div className="text-2xl opacity-60">{icon}</div>}
      </div>

      {/* Change indicator */}
      <div className="flex items-center gap-1 text-green-400 text-sm">
        <TrendingUp className="w-4 h-4" />
        <span className="font-semibold">+{change}%</span>
        <span className="text-gray-500 ml-1">{unit}</span>
      </div>
    </div>
  )
}
