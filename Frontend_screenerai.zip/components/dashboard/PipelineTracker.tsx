import { pipelineStages } from '@/lib/data'

export function PipelineTracker() {
  return (
    <div className="glass-card-hover p-8 col-span-2">
      <h3 className="text-lg font-semibold text-white mb-8">Pipeline Overview</h3>

      <div className="relative">
        {/* Pipeline stages */}
        <div className="flex items-end justify-between">
          {pipelineStages.map((stage, index) => (
            <div key={index} className="flex flex-col items-center flex-1">
              {/* Stage circle */}
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center font-semibold text-sm mb-4 transition-all ${
                  stage.status === 'completed'
                    ? 'bg-cyan-400/30 text-cyan-300 border border-cyan-400/50'
                    : 'bg-teal-400/30 text-teal-300 border border-teal-400/50'
                }`}
              >
                {stage.count}
              </div>

              {/* Stage name */}
              <p className="text-xs font-medium text-gray-400 text-center">{stage.name}</p>

              {/* Connecting line */}
              {index < pipelineStages.length - 1 && (
                <div className="absolute top-5 left-[calc(50%+24px)] right-[calc(50%-24px)] h-1 bg-gradient-to-r from-cyan-400/30 to-teal-400/30 pointer-events-none"></div>
              )}
            </div>
          ))}
        </div>

        {/* Labels */}
        <div className="flex justify-between mt-6 text-xs text-gray-500">
          <span>JD Parsing</span>
          <span>Candidate Discovery</span>
          <span>Engagement</span>
          <span>Shortlist Ready</span>
        </div>
      </div>
    </div>
  )
}
