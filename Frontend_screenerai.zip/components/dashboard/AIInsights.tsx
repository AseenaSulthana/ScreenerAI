import { aiInsights } from '@/lib/data'
import { Lightbulb, ArrowRight } from 'lucide-react'

export function AIInsights() {
  return (
    <div className="glass-card-hover p-6 col-span-1">
      <div className="flex items-center gap-2 mb-6">
        <Lightbulb className="w-5 h-5 text-yellow-400" />
        <h3 className="text-lg font-semibold text-white">AI Insights</h3>
      </div>

      <div className="space-y-3">
        {aiInsights.map((insight, index) => (
          <div key={index} className="flex gap-3 p-3 bg-white/5 rounded-lg border border-white/10">
            <span className="text-lg flex-shrink-0">{insight.icon}</span>
            <p className="text-xs text-gray-300 leading-relaxed">{insight.text}</p>
          </div>
        ))}
      </div>

      <a href="#" className="mt-4 flex items-center justify-center gap-2 w-full px-4 py-2 bg-yellow-400/20 text-yellow-300 border border-yellow-400/30 rounded-lg hover:bg-yellow-400/30 transition-colors text-sm font-semibold">
        View Analytics
        <ArrowRight className="w-4 h-4" />
      </a>
    </div>
  )
}
