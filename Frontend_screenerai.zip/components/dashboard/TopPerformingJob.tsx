import { topPerformingJob } from '@/lib/data'
import { ArrowRight, Eye } from 'lucide-react'

export function TopPerformingJob() {
  return (
    <div className="glass-card-hover p-6 col-span-1">
      <h3 className="text-lg font-semibold text-white mb-1">{topPerformingJob.title}</h3>
      <p className="text-xs text-green-400 font-semibold mb-6 inline-flex items-center gap-1">
        <span className="w-2 h-2 bg-green-400 rounded-full"></span>
        {topPerformingJob.status}
      </p>

      <div className="space-y-4 mb-6">
        <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/10">
          <span className="text-sm text-gray-400">Candidates Discovered</span>
          <span className="font-semibold text-cyan-400">{topPerformingJob.candidatesDiscovered}</span>
        </div>
        <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/10">
          <span className="text-sm text-gray-400">Response Rate</span>
          <span className="font-semibold text-teal-400">{topPerformingJob.responseRate}%</span>
        </div>
        <div className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/10">
          <span className="text-sm text-gray-400">Shortlist</span>
          <span className="font-semibold text-purple-400">{topPerformingJob.shortlist}</span>
        </div>
      </div>

      <button className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-cyan-400/20 text-cyan-300 border border-cyan-400/30 rounded-lg hover:bg-cyan-400/30 transition-colors text-sm font-semibold">
        <Eye className="w-4 h-4" />
        View Details
        <ArrowRight className="w-4 h-4" />
      </button>
    </div>
  )
}
