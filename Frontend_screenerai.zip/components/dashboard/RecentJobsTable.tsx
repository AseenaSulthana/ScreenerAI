'use client'

import { recentJobs } from '@/lib/data'
import { ArrowRight } from 'lucide-react'

const statusConfig: Record<string, { badge: string; color: string }> = {
  'Shortlist Ready': { badge: 'status-shortlist', color: 'text-cyan-300' },
  Engagement: { badge: 'status-engagement', color: 'text-teal-300' },
  Discovery: { badge: 'status-discovery', color: 'text-blue-300' },
  'JD Parsing': { badge: 'status-parsing', color: 'text-purple-300' },
}

export function RecentJobsTable() {
  return (
    <div className="glass-card-hover p-6 col-span-2">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-white">Recent Job Descriptions</h3>
        <a href="#" className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1">
          View All Jobs
          <ArrowRight className="w-3 h-3" />
        </a>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-white/10">
              <th className="text-left py-3 px-4 text-gray-500 font-medium">Job Title</th>
              <th className="text-left py-3 px-4 text-gray-500 font-medium">Status</th>
              <th className="text-right py-3 px-4 text-gray-500 font-medium">Candidates</th>
              <th className="text-right py-3 px-4 text-gray-500 font-medium">Response Rate</th>
              <th className="text-right py-3 px-4 text-gray-500 font-medium">Updated On</th>
              <th className="text-right py-3 px-4 text-gray-500 font-medium">Shortlist</th>
            </tr>
          </thead>
          <tbody>
            {recentJobs.map((job) => {
              const config = statusConfig[job.status] || statusConfig['Discovery']
              return (
                <tr key={job.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="py-3 px-4 text-white font-medium">{job.title}</td>
                  <td className="py-3 px-4">
                    <span className={`status-badge ${config.badge}`}>{job.status}</span>
                  </td>
                  <td className="py-3 px-4 text-right text-cyan-400 font-semibold">{job.candidatesDiscovered}</td>
                  <td className="py-3 px-4 text-right text-teal-400 font-semibold">
                    {job.responseRate}%
                  </td>
                  <td className="py-3 px-4 text-right text-gray-500">{job.updatedAt}</td>
                  <td className="py-3 px-4 text-right text-purple-400 font-semibold">{job.shortlist}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
