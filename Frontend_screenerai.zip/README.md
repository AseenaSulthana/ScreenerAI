# Deccan AI Experts - Recruitment Platform

A modern, AI-powered recruitment platform built with Next.js 16, React 19, and Tailwind CSS. Features a sophisticated dark teal gradient theme with glassmorphic design elements and a charming AI chatbot mascot.

## Authentication

### Login Page (`/`) - Landing Page
The login page is now the main landing page with:
- Email and password authentication fields
- AI Chatbot mascot at the top asking for credentials
- Animated chatbot greeting: "Welcome back! Let's find great talent together"
- Show/hide password toggle for security
- Demo credentials provided for testing (demo@deccan.ai / demo123)
- Password recovery link
- Signup redirect link for new users
- Glassmorphic design matching the platform aesthetic
- Animated background elements for visual appeal

### Signup Page (`/signup`)
- Full name, email, and password registration
- Password strength validation indicator
- Requirements: 8+ chars, uppercase, lowercase, number
- Password confirmation field
- Terms and conditions acceptance
- Existing user sign-in redirect
- AI chatbot branding

## Features

### Dashboard (`/dashboard`) - Main Dashboard
- **KPI Cards**: Real-time metrics for active jobs, discovered candidates, conversations, response rates, and shortlists
- **Pipeline Tracker**: Visual representation of the recruitment funnel with step-wise progress
- **Top Performing Job**: Spotlight on best-performing job listings
- **Recent Jobs Table**: Sortable table with job status and metrics
- **AI Insights**: Machine learning-generated insights for recruitment optimization

### JD Parser (`/jd-parser`) ⭐ NEW
The core feature for automated candidate matching:
- **Resume Upload**: Upload multiple PDF/DOC resume files for bulk candidate analysis
- **JD Input**: Paste or upload full job descriptions
- **Advanced Form**:
  - Job title and department
  - Years of experience required
  - Education requirements
  - Required skills (with smart suggestions)
  - Key responsibilities
- **AI Parsing**: Extracts role, experience, skills, and responsibilities with confidence scores
- **Smart Matching**: Automatically matches candidates from uploaded resumes against JD criteria
- **Match Results**:
  - Individual candidate cards with match scores (0-100%)
  - Interest score visualization
  - Relevant skills highlighting
  - Location and experience display
  - Engage or download resume actions
- **Export & Sync**: Export results to ATS systems with one click

### Multi-Step Workflow (`/workflow`)
A comprehensive 5-step recruitment workflow:
1. **JD Input** - Job description upload and text input
2. **JD Parsing** - AI extraction of key requirements with confidence scores
3. **Candidate Discovery** - Search and filter qualified candidates with match scoring
4. **Engagement** - AI-powered chatbot for candidate interaction with interest scoring
5. **Shortlist** - Ranked candidate list with scatter plot visualization

### Engagement Management (`/engagements`)
- AI-powered candidate conversations and chat history
- Real-time engagement tracking with status indicators
- Response rate monitoring (In Progress, Waiting, Completed)
- Continue conversation with candidates directly

### Shortlist Management (`/shortlists`)
- View and manage candidate shortlists per job
- Match score visualization with progress bars
- Quick actions: View, Share, Export, Delete
- Batch export capabilities
- ATS system integration with one-click sync

### Analytics Dashboard (`/analytics`)
- Total candidates sourced metrics
- Average response time tracking
- Conversion rate monitoring
- Engagement score visualization
- Trend analysis with percentage changes

### Job Descriptions (`/jobs`)
- Job postings management and creation
- Candidate count per job position
- Performance metrics and response tracking
- Quick action buttons for each listing

### Candidates (`/candidates`)
- Candidate profile browser with search
- Advanced filtering by skills and experience
- Skills and experience display
- Engagement history and interaction logs
- Profile editing and notes

### ATS Integrations (`/integrations`)
- Connect to Workday, Greenhouse, and LinkedIn Recruiter
- Slack and Teams notification setup
- Email tracking integration
- Connection status monitoring
- One-click configuration for supported systems

### Settings (`/settings`)
- Profile and account management
- Notification preferences (Email, Slack, etc.)
- Security settings and password management
- Two-factor authentication (2FA) setup
- Theme customization options

## Design System

### Color Palette
- **Primary Background**: #061A1A (Dark Navy)
- **Secondary Background**: #0B2F2F (Dark Teal)
- **Primary Accent**: #00FFC6 (Bright Cyan)
- **Secondary Accent**: #00C2A8 (Teal)
- **Text Primary**: #E8F4F4 (Light Cyan)
- **Text Secondary**: #7FC4C4 (Muted Cyan)

### Component Library
- **Glass Cards**: Frosted glass effect with backdrop blur
- **Status Badges**: Color-coded status indicators
- **Gradient Text**: Modern gradient typography
- **Animations**: Smooth transitions and fade-in effects

## Technology Stack

- **Framework**: Next.js 16 with App Router
- **UI Components**: shadcn/ui + custom components
- **Styling**: Tailwind CSS v4
- **Charts**: Recharts for data visualization
- **Icons**: Lucide React
- **Font**: Geist (Google Fonts)

## Project Structure

```
app/
├── page.tsx                  # Dashboard home page
├── jd-parser/                # JD Parser with resume upload
├── workflow/                 # Multi-step workflow
├── jobs/                     # Jobs listing page
├── candidates/               # Candidates browser page
├── engagements/              # Engagement tracking page
├── shortlists/               # Shortlist management page
├── analytics/                # Analytics dashboard page
├── integrations/             # ATS integrations page
├── settings/                 # Settings and preferences page
└── layout.tsx                # Root layout with dark mode
components/
├── layout/
│   ├── Sidebar.tsx           # Main navigation
│   └── Navbar.tsx            # Top navigation bar
├── dashboard/                # Dashboard components
│   ├── StatCard.tsx
│   ├── PipelineTracker.tsx
│   ├── TopPerformingJob.tsx
│   ├── RecentJobsTable.tsx
│   └── AIInsights.tsx
├── workflow/                 # Workflow step components
│   ├── JDInput.tsx
│   ├── ParsedInsights.tsx
│   ├── CandidateDiscovery.tsx
│   ├── CandidateCard.tsx
│   ├── ChatbotPanel.tsx
│   ├── InterestScore.tsx
│   ├── ScatterPlot.tsx
│   └── ShortlistTable.tsx
└── jd-parser/                # JD Parser components
    ├── JDParserStep.tsx      # Parsing results display
    ├── SkillsInput.tsx       # Skills suggestion & input
    └── CandidateMatchResults.tsx  # Match results display
lib/
├── data.ts                   # Comprehensive dummy data
├── types.ts                  # TypeScript types
└── utils.ts                  # Tailwind utility functions
```

## Getting Started

### Prerequisites
- Node.js 18+
- pnpm (or npm/yarn)

### Installation

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev

# Open http://localhost:3000 in browser
```

### Using the JD Parser

1. Navigate to **JD Parser** from the left sidebar
2. **Upload Resumes**:
   - Click the upload area or drag & drop
   - Select PDF or DOC/DOCX files (up to 10MB each)
   - Multiple files can be uploaded at once
3. **Enter Job Description**:
   - Paste the complete job description in the textarea
   - Or upload a JD file
4. **Fill Job Details**:
   - **Job Title**: e.g., "Senior Machine Learning Engineer"
   - **Department**: e.g., "Engineering"
   - **Years of Experience**: e.g., "4+ years"
   - **Education**: e.g., "Bachelor's / Master's in CS"
5. **Add Requirements**:
   - **Required Skills**: Click + to add skills (Python, NLP, AWS, etc.)
   - **Key Responsibilities**: Click + to add responsibilities
6. **Parse & Match**:
   - Click "Parse JD & Find Matches" button
   - AI will analyze resumes and find matching candidates
7. **Review Results**:
   - View candidates with match scores (0-100%)
   - See interest scores and relevant skills
   - Click "Engage" to start conversation
   - Click "Resume" to download candidate file
8. **Export**:
   - Click "Sync to ATS" to send to your system
   - Click "Export Results" to download results file

### Available Routes
- `/` - **Login Page (Landing Page)** with AI Chatbot
- `/dashboard` - Main dashboard with KPI cards and pipeline
- `/jd-parser` - JD Parser with resume upload and candidate matching
- `/workflow` - Multi-step recruitment workflow
- `/jobs` - Job listings
- `/candidates` - Candidate browser
- `/engagements` - Engagement tracking
- `/shortlists` - Shortlist management
- `/analytics` - Analytics dashboard
- `/integrations` - ATS integrations
- `/settings` - Settings and preferences
- `/signup` - User registration page

## Key Features

### Responsive Design
- Mobile-first approach
- Sidebar collapses on smaller screens
- Grid layouts adapt to screen size

### Dark Mode
- Always-on dark theme matching brand colors
- Optimized for extended viewing
- Consistent color scheme across all pages

### Interactive Components
- Tabbed workflow navigation
- Sortable tables
- Filterable candidate lists
- Real-time search
- Hover animations and visual feedback

### Data Visualization
- Scatter plot showing candidate match vs interest scores
- Circular progress indicators
- Progress bars with gradients
- Status badge system

## Customization

### Colors
Edit the CSS variables in `app/globals.css` under the `.dark` selector to change the color scheme.

### Data
Modify dummy data in `lib/data.ts` to populate different content.

### Components
All components are modular and reusable. Check `components/` for individual component implementations.

## Performance

- Optimized for fast load times with Next.js 16
- CSS-in-JS with Tailwind for minimal bundle size
- Server-side rendering for SEO
- Optimized images and assets

## Deployment

Deploy easily to Vercel:

```bash
# Using Vercel CLI
vercel

# Or connect GitHub repo to Vercel Dashboard
```

## License

Built with v0 - Vercel's AI-powered code generator.

---

**Note**: This is a demo application with mock data. For production use, integrate with real APIs and databases.
